﻿using DafoApi.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DafoApi
{
    public class DafoSqlAnswer
    {
        public string sqlAnswer(string sqlQuery)
        {
            if (DafoTypes.answerType == "Person")
                return sqlAnswerPerson(sqlQuery);
            if (DafoTypes.answerType == "Paper")
                return sqlAnswerPaper(sqlQuery);
            if (DafoTypes.answerType == "Conference")
                return sqlAnswerConference(sqlQuery);
            if (DafoTypes.answerType == "Proceedings")
                return sqlAnswerProc(sqlQuery);

            return "";
        }

        public string sqlAnswerProc(string sqlQuery)
        {
            DAFO_02Context dbCtx = new DAFO_02Context();
            var ansListId = dbCtx.MvAnswerId.FromSql(sqlQuery).ToList();
            var ansProc = (from p in dbCtx.Proceedings
                            from pid in ansListId
                            where p.Id == pid.Id
                            select new {p.Id, p.Year, p.BookTitle, p.Series, p.Publisher, p.Volume, p.Editor }
                            ).OrderBy(x => x.Year).ThenByDescending(x => x.BookTitle);
            string ansJSON = @"{'answer':[";
            foreach (var p in ansProc)
            {
                if (ansJSON.Length > 15)
                {
                    ansJSON += ",";
                }
                ansJSON += "{'id':" + "'" + p.Id.ToString() + "'" + ",'text':'"
                    + ((p.BookTitle == null || p.BookTitle == "") ? "" : ", " + p.BookTitle.Trim().Replace("\\'","").Replace("'", " "))
                    //+ ((p.Editor == null || p.Editor == "")       ? "" : ", "+p.Editor.Trim())
                    + ((p.Series == null | p.Series == "") ? "" : p.Series.Trim().Replace("'", " "))
                    + ((p.Volume == null || p.Volume == "") ? "" : ", " + p.Volume.Trim())
                    + ((p.Publisher == null || p.Publisher == "") ? "" : ", " + p.Publisher.Trim())
                    + ((p.Year == null) ? "" : ", " + p.Year.ToString())
                    + "'}";
            }
            ansJSON += "]}";
            dbCtx.Dispose();
            return ansJSON;
        }

        public string sqlAnswerConference(string sqlQuery)
        {
            DAFO_02Context dbCtx = new DAFO_02Context();
            var ansListId = dbCtx.MvAnswerId.FromSql(sqlQuery).ToList();
            var ansConference = (from p in dbCtx.Conference
                            from pid in ansListId
                            where p.Id == pid.Id
                            select new { p.Id, p.Acronym, p.ShortName, p.FullName, p.EditionNo, p.Year, p.Country, p.City, p.Organizer}
                            ).OrderByDescending(x=>x.Year).ThenBy(x => x.Acronym);
            string ansJSON = @"{'answer':[";
            foreach (var p in ansConference)
            {
                if (ansJSON.Length > 15)
                {
                    ansJSON += ",";
                }
                ansJSON += "{'id':" + "'" + p.Id.ToString() + "'" + ",'text':'"
                    + ((p.Acronym == null || p.Acronym == "")       ? "" : p.Acronym.Trim().Replace("'", " "))
                    + ((p.Year == null)                             ? "" : ", " + p.Year.ToString())
                    + ((p.ShortName == null || p.ShortName =="")    ? "" : ", "+p.ShortName.Trim().Replace("'", " "))
                    + ((p.FullName == null || p.FullName =="")      ? "" : ", " + p.FullName.Trim().Replace("'", " "))
                    + ((p.EditionNo == null || p.EditionNo == "")   ? "" : ", " + p.EditionNo)
                    + ((p.Country == null || p.Country == "")       ? "" : ", " + p.Country.Trim())
                    + ((p.City == null || p.City == "")             ? "" : ", " + p.City.Trim())
                    + ((p.Organizer == null || p.Organizer == "")   ? "" : ", " + p.Organizer.Trim().Replace("'", " "))                   
                    + "'}";
            }
            ansJSON += "]}";
            dbCtx.Dispose();
            return ansJSON;
        }

        public string sqlAnswerPaper(string sqlQuery)
        {
            DAFO_02Context dbCtx = new DAFO_02Context();
            var ansListId = dbCtx.MvAnswerId.FromSql(sqlQuery).ToList();
            var ansPaper = (from p in dbCtx.Paper
                            from pid in ansListId
                            where p.Id == pid.Id
                            select new {p.Id, p.LastName, Year = p.Proc.Year, p.Authors, p.Title, p.Pages, BookTitle = p.Proc.BookTitle, p.Proc.Series, p.Proc.Publisher, p.Proc.Volume }
                            ).OrderBy(x => x.LastName).ThenByDescending(x => x.Year);
            string ansJSON = @"{'answer':[";
            foreach (var p in ansPaper)
            {
                if (ansJSON.Length > 15)
                {
                    ansJSON += ",";
                }
                ansJSON += "{'id':" + "'" + p.Id.ToString() + "'" + ",'text':'"
                    + ((p.Authors == null || p.Authors == "")      ? "" : p.Authors.Trim().Replace("'", " "))
                    + ((p.Title == null || p.Title == "")           ? "" : ": " + p.Title.Trim().Replace("'", " "))
                    + ((p.BookTitle == null || p.BookTitle == "")   ? "" : ", " + p.BookTitle.Trim().Replace("\\'", "").Replace("'", " "))
                    + ((p.Series == null | p.Series == "")          ? "" : p.Series.Trim().Replace("'", " "))
                    + ((p.Volume == null || p.Volume == "")         ? "" : ", " + p.Volume.Trim())
                    + ((p.Publisher == null || p.Publisher == "")   ? "" : ", " + p.Publisher.Trim())
                    + ((p.Pages == null || p.Pages == "")           ? "" : ", pp." + p.Pages.Trim())
                    + ((p.Year == null)                             ? "" : ", " + p.Year.ToString()) 
                    + "'}";
            }
            ansJSON += "]}";
            dbCtx.Dispose();
            return ansJSON;
        }

        public string sqlAnswerPerson(string sqlQuery)
        {
            DAFO_02Context dbCtx = new DAFO_02Context();
            var ansListId = dbCtx.MvAnswerId.FromSql(sqlQuery).ToList();
            var ansPerson = (from p in dbCtx.Person
                             from pid in ansListId
                             where p.Id == pid.Id
                             select new { p.Id, p.LastName, p.Name}).OrderBy(x => x.LastName);
            //select new {p.Id,p.LastName,p.Name,p.Affiliation,p.Affiliation1,p.Affiliation2,p.Affiliation3}).OrderBy(x => x.LastName);
            
            string ansJSON = @"{'answer':[";
            foreach (var p in ansPerson)
            {
                var personAffil = (from a in dbCtx.Affiliation
                                   where a.PersonId == p.Id
                                   select a.Affiliation1).ToList();
                if (ansJSON.Length > 15)
                {
                    ansJSON += ",";
                }
                string txt = p.Name + "; " + personAffil[0];
                if (personAffil.Count() > 1 && personAffil[1] != null)
                {
                    txt += "; " + personAffil[1];
                }
                if (personAffil.Count() > 2 && personAffil[2] != null)
                {
                    txt += "; " + personAffil[2];
                }
                if (personAffil.Count() > 3 && personAffil[3] != null)
                {
                    txt += "; " + personAffil[3];
                }
                ansJSON += "{'id':" + "'" + p.Id.ToString() + "'" + ",'text':" + "'" + txt + "'}";
            }
            ansJSON += "]}";
            dbCtx.Dispose();
            return ansJSON;
        }
        //=================================================
        // VALUES
        //=================================================

        public string valuesToJSON(string attName, string query)
        {
            List<string> allValList = GetValueList(attName, query);
            int nodeId = 1;
            string strJSON = "[";
            foreach (string s in allValList)
            {
                if (nodeId > 1)
                {
                    strJSON += ",";
                }
                nodeId++;
                //strJSON += "{ 'id': 'val-" + nodeId.ToString() + "', 'text': '" + s +"', 'icon': ' '} ";
                strJSON += "{'text': '" + s + "', 'icon': ' ','li_attr': { 'class': 'val const incl'}}";
            }
            return strJSON + "]";
        }

        public List<string> GetValueList(string attName, string query)
        {
            DAFO_02Context dbCtx = new DAFO_02Context();
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
            //opis atrybutu w ontologii
            var attMap = (from t in ontoCtx.Sigma
                          where t.Name == attName
                          select new { TabMap = t.TabMap, AttMap = t.AttMap, DomMap = t.DomMap, RngMap = t.RngMap }).FirstOrDefault();
            string tabName = attMap.TabMap;
            string colName = attMap.RngMap;
            string sqlQuery = "";
            if (colName == "Id")
            {
                sqlQuery = "SELECT DISTINCT cast(" + tabName + ".Id as char(8)) AS [Values] FROM " + tabName
                    + ", (" + query + ") as IdTab"
                      + " WHERE " + tabName + ".Id=IdTab.Id";
            }
            else
            {
                sqlQuery = "SELECT DISTINCT Replace(" + colName + ", '''', ' ') AS [Values] FROM " + tabName
                    + ", (" + query + ") as IdTab"
                      + " WHERE " + tabName + ".Id=IdTab.Id and "
                      + colName + " is not null and len(" + colName + ")>0 order by [Values]";
            }
            //wykonanie
            //List<String> uniqueVal;
            var uniqueVal = dbCtx.MvValues.FromSql(sqlQuery).ToList();
            var attValList = (from v in uniqueVal
                              select v.Values).ToList();
           // dolaczyc wzorce z DAFO_ONTO..Spec1
            List<String> patterns = (from s in ontoCtx.Spec1
                                     where s.Bname == attName && s.Const.Contains("%")
                                     select s.Const).Distinct().ToList();
            dbCtx.Dispose();
            List<string> allValList = patterns.Concat(attValList).ToList();
            return allValList;
        }

    }
}
