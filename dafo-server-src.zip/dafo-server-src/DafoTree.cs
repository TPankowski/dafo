﻿using DafoApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;


namespace DafoApi
{
    public class DafoTree
    {
        static int nodeId = 0;
        static string[] strTab;
        static string[] topTab;
        static string[] parTab;
        static string[] chiTab;

        public class Family
        {
            public string parent;
            public List<string> children = new List<string>();
        }

        public List<Family> familyList = new List<Family>();

        public string getClassHierarchyList()
        {
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
            List<string> classList = (from t in ontoCtx.MvSubTypeAll
                                      select t.Uname).ToList();
            string classStr = "";
            foreach (string s in classList)
            {
                if (classStr == "")
                    classStr = s;
                else
                    classStr += "," + s;
            }
            List<string> classListMax = (from t in ontoCtx.MvSubTypeAll
                                         select t.MaxType).ToList();
            ontoCtx.Dispose();
            string classStrMax = "";
            foreach (string s in classListMax)
            {
                if (classStrMax == "")
                    classStrMax = s;
                else
                    classStrMax += "," + s;
            }
            return classStr + ";" + classStrMax;
        }


        public string strToJSON(string strTree)
        {
            string jsonTree = "";
            try
            {
                strTab = strTree.Split(";");
                topTab = strTab[0].Split(",");
                parTab = strTab[1].Split(",");
                chiTab = strTab[2].Split(",");
                createFamilies(familyList);

                //jsonTree = "[{'id' : 0, 'text': 'root','icon':'BpIcon'," +
                //   "'state' : { 'selected' : true, 'opened' : true,'checked' : true }, 'li_attr': { 'class': 'or om incl'}, 'children':[" + createTree() + "]}]";
                jsonTree = "[{'text': 'root','icon':'BpIcon'," +
                        "'state' : { 'selected' : true, 'opened' : true,'checked' : true }, 'li_attr': { 'class': 'or om incl'}, 'children':[" + createTree() + "]}]";
            }
            catch (Exception e)
            {
                jsonTree = @"[{'id': 'ajson1', 'parent': '#', 'text': '== ERROR =='}]";
            }
            return jsonTree;
        }

        public string dataPropertiesJSON(string unode)
        {
            DAFO_ONTOContext db = new DAFO_ONTOContext();
            List<string> dataPropList = (from s in db.MvMaxSuperClasses
                                         from d in db.Dom
                                         from r in db.Rng
                                         where s.Uname == unode && s.UnameMax == d.Uname
                                         && d.Bname == r.Bname && (r.Uname == "String" || r.Uname == "Integer")
                                         select d.Bname).ToList();
            nodeId++;
            string strJSON = "";
            foreach (string s in dataPropList)
            {
                if (!s.Contains("Key"))
                {
                    nodeId++;
                    if (strJSON.Length > 1 && strJSON.Substring(strJSON.Length - 1, 1) == "}")
                    {
                        strJSON += ",";
                    }
                    //strJSON += "{ 'id': " + nodeId.ToString() + ", 'text': '" + s + "'"
                    //    + ",'icon':' AttIcon', 'li_attr': {'class': 'no dm incl'}}";
                    strJSON += "{'text': '" + s + "', 'icon':' AttIcon', 'li_attr': {'class': 'no dm incl'}}";
                }
            }
            return strJSON;
        }

        public string createTree()
        {
            string str = "";
            for (int i = 0, count = topTab.Length; i < count; i++)
            {
                str += createNode(topTab[i]);
                if (i < count - 1)
                {
                    str += ",";
                }
            }
            return str;
        }
        public string createNode(string text)
        {
            nodeId++;
            //string nodeStr = "{ 'id': " + nodeId.ToString() + ", 'text': '" + text + "'"  //+ " [xAND]'"
            //    + ",'icon':'UpIcon','state' : { 'selected' : false, 'opened' : true,'checked' : true }"
            //    + ",'li_attr': {'class': 'and up incl'}"
            //    + ", 'children': [" + dataPropertiesJSON(text) + createChildrenFromFamily(text, familyList) + "]}";
            string nodeStr = "{'text': '" + text + "'"  //+ " [xAND]'"
                + ",'icon':'UpIcon','state' : { 'selected' : false, 'opened' : true,'checked' : true }"
                + ",'li_attr': {'class': 'and up incl'}"
                + ", 'children': [" + dataPropertiesJSON(text) + createChildrenFromFamily(text, familyList) + "]}";
            return nodeStr.Replace("}{", "},{");
        }

        public string createChildren(string parent)
        {
            string strJSON = "";
            for (int i = 0, count = parTab.Length; i < count; i++)
            {
                if (parTab[i] == parent)
                {
                    DAFO_ONTOContext db = new DAFO_ONTOContext();
                    string child = chiTab[i];
                    List<string> objPropList = (from s1 in db.MvMaxSuperClasses
                                                from s2 in db.MvMaxSuperClasses
                                                from d in db.Dom
                                                from r in db.Rng
                                                where s1.Uname == parent && s2.Uname == child &&
                                                s1.UnameMax == d.Uname && s2.UnameMax == r.Uname
                                                && d.Bname == r.Bname && r.Uname != "String"
                                                select d.Bname).ToList();
                    foreach (string s in objPropList)
                    {
                        nodeId++;
                        //strJSON += "{ 'id': " + nodeId.ToString() + ", 'text': '" + s //+ " [xOR]'"
                        //    + "', 'icon':'BpIcon'" + ", 'state' : {'selected' : false, 'opened' : true, 'checked' : true}, 'li_attr': { 'class': 'or om incl'}, 'children':[";
                        strJSON += "{'text': '" + s //+ " [xOR]'"
                            + "', 'icon':'BpIcon'" + ", 'state' : {'selected' : false, 'opened' : true, 'checked' : true}, 'li_attr': { 'class': 'or om incl'}, 'children':[";

                        strJSON += createNode(chiTab[i]) + "]}".Replace("}{", "},{");
                    }
                }
            }
            return strJSON;
        }

        public string createChildrenFromFamily(string parent, List<Family> familyList)
        {
            string strJSON = "";
            for (int i = 0, count = familyList.Count(); i < count; i++)
            {
                if (familyList[i].parent == parent)
                {
                    familyList[i].parent = "*";//juz przeanalizowane, wazne dla cyklicznych sciezek
                    DAFO_ONTOContext db = new DAFO_ONTOContext();
                    string child = familyList[i].children[0];
                    List<string> objPropList = (from s1 in db.MvMaxSuperClasses
                                                from s2 in db.MvMaxSuperClasses
                                                from d in db.Dom
                                                from r in db.Rng
                                                where s1.Uname == parent && s2.Uname == child &&
                                                s1.UnameMax == d.Uname && s2.UnameMax == r.Uname
                                                && d.Bname == r.Bname && r.Uname != "String"
                                                select d.Bname).ToList();
                    foreach (string s in objPropList)
                    {
                        nodeId++;
                        //strJSON += "{ 'id': " + nodeId.ToString() + ", 'text': '" + s //+ " [xOR]'" 
                        //    + "', 'icon':'BpIcon'" + ", 'state' : {'selected' : false, 'opened' : true, 'checked' : true}, 'li_attr': { 'class': 'or om incl'}, 'children':[";
                        strJSON += "{'text': '" + s //+ " [xOR]'" 
                            + "', 'icon':'BpIcon'" + ", 'state' : {'selected' : false, 'opened' : true, 'checked' : true}, 'li_attr': { 'class': 'or om incl'}, 'children':[";

                        foreach (string son in familyList[i].children)
                        {
                            strJSON += createNode(son);
                        }
                        strJSON += "]}".Replace("}{", "},{");
                    }
                }
            }
            return strJSON;
        }

        public void createFamilies(List<Family> familyList)
        {
            bool inFamily = false;
            for (int i = 0, count = parTab.Length; i < count; i++)
            {
                foreach (var f in familyList)
                {
                    if (f.parent == parTab[i])
                    {
                        if (maxClass(chiTab[i]) == maxClass(f.children[0]))
                        {
                            f.children.Add(chiTab[i]);
                            inFamily = true;
                            break;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                if (!inFamily)
                {
                    Family newFam = new Family();
                    newFam.parent = parTab[i];
                    newFam.children.Add(chiTab[i]);
                    familyList.Add(newFam);
                }
                else
                {
                    inFamily = false;
                }
            }
        }

        public string maxClass(string uname)
        {
            DAFO_ONTOContext db = new DAFO_ONTOContext();
            string className = (from s in db.MvMaxSuperClasses
                                where s.Uname == uname
                                select s.UnameMax).FirstOrDefault();
            return className;
        }
    }
}

