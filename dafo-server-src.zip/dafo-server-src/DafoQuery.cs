﻿using DafoApi.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DafoApi
{
    public class DafoQuery
    {
        public class NodeType
        {
            public string id;
            public string text;
            public string parent;
            public string attr;
        }

        public int variableNo = 0;

        public static List<DafoTypes.ExpNode> ExpNodeList = new List<DafoTypes.ExpNode>();

        /*
        static string jsonStr = @"{dafo:{par1:'values',par2:'name',
        tree:[{id:'j1_1',text:'root',parent:'#',attr:'or om incl'}
        ,{id:'j1_2',text:'Person',parent:'j1_1',attr:'and up incl'}
        ,{id:'j1_5',text:'authorConf [ count() > 10 ]',parent:'j1_2',attr:'and om incl'}
        ,{id:'j1_6',text:'ACMConf',parent:'j1_5',attr:'and up incl'}
        ,{id:'j1_13',text:'USAConf',parent:'j1_5',attr:'and up excl'}]}
        }";
        */
        //static string jsonStr = @"{tree:[{id:'j1_1',text:'root',parent:'#',attr:'or om incl'},{id:'j1_2',text:'Person',parent:'j1_1',attr:'and up incl'}
        //,{id:'j1_3',text:'affiliation',parent:'j1_2',attr:'no dm incl'},{id:'j1_4',text:'name',parent:'j1_2',attr:'no dm incl'},{id:'j1_32',text:'Donald Kossmann',parent:'j1_4',attr:'val const incl'},{id:'j1_75',text:'Tadeusz Pankowski',parent:'j1_4',attr:'val const incl'},{id:'j1_5',text:'authorConf',parent:'j1_2',attr:'or om incl'},{id:'j1_6',text:'ACMConf',parent:'j1_5',attr:'and up incl'},{id:'j1_7',text:'acronym',parent:'j1_6',attr:'no dm incl'},{id:'j1_8',text:'city',parent:'j1_6',attr:'no dm incl'},{id:'j1_9',text:'confName',parent:'j1_6',attr:'no dm incl'},{id:'j1_10',text:'confYear',parent:'j1_6',attr:'no dm incl'},{id:'j1_11',text:'country',parent:'j1_6',attr:'no dm incl'},{id:'j1_12',text:'editionNo',parent:'j1_6',attr:'no dm incl'},{id:'j1_13',text:'USAConf',parent:'j1_5',attr:'and up incl'},{id:'j1_14',text:'acronym',parent:'j1_13',attr:'no dm incl'},{id:'j1_15',text:'city',parent:'j1_13',attr:'no dm incl'},{id:'j1_81',text:'Poznań',parent:'j1_15',attr:'val const incl'},{id:'j1_16',text:'confName',parent:'j1_13',attr:'no dm incl'},{id:'j1_17',text:'confYear',parent:'j1_13',attr:'no dm incl'},{id:'j1_18',text:'country',parent:'j1_13',attr:'no dm incl'}]}";

        public JObject treeJSON; // = JObject.Parse(jsonStr);
        public JArray nodesJSON; // = (JArray)treeJSON["tree"];
        public List<NodeType> nodeList = new List<NodeType>();

        

        public string CreateQueryExp(JArray treeArray, DafoTypes.ExpNode rootExp, string execMode)
        {
            //treeJSON = JObject.Parse(jsonStr);
            string jsonBefore = "";
            string jsonAfter = "";
            nodesJSON = treeArray; // (JArray)treeJSON["tree"];
            nodeList.Clear();
            for (int i = 0; i < nodesJSON.Count(); i++)
            {
                NodeType node = nodesJSON[i].ToObject<NodeType>();
                nodeList.Add(node);
                if (i == 1) // szczytowy element pod root
                {
                    DafoTree dt = new DafoTree();
                    DafoTypes.answerType = dt.maxClass(node.text);
                }
            }
            createTreeExp(rootExp, "#","AndOr",nodeList, "x","x"); //tworzenie treeView ze zbioru nodes
            setCountStack(rootExp, "","");
            setCycleStack(rootExp);
            if (execMode == "answer")
            {
                jsonBefore = FOtoJSON(rootExp);
            }
            DafoTypes.isRewritten = true;
            while (DafoTypes.isRewritten)
            {
                DafoTypes.isRewritten = false;
                RewriteQuery(rootExp);
            }
            setCountStack(rootExp,"","");
            firstCycleVar = "";
            leftCycleVar = "";
            lastCycleVar = "";
            rightCycleVar = "";
            aliasCycle = "";
            cyclePath = "";
            setCycleStack(rootExp);
            delCycleVar(rootExp);
            SetTranslationInformation(rootExp);
            if (execMode == "answer")
            {
                jsonAfter = FOtoJSON(rootExp);
            }
            DafoSqlQuery sq = new DafoSqlQuery();
            string sqlQuery = sq.SqlQuery(rootExp);
            if (execMode == "answer")
            {
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                Guid g = Guid.NewGuid();
                DafoTypes.token = g.ToString();
                string sqlHTML = SqlToHTML(sqlQuery);
                ontoCtx.TransLog.Add(new TransLog() { Token = DafoTypes.token, Kind = "SQLQuery", JsonStr = sqlHTML, CreateTime = DateTime.Now });
                ontoCtx.TransLog.Add(new TransLog() { Token = DafoTypes.token, Kind = "Before", JsonStr = jsonBefore, CreateTime = DateTime.Now });
                ontoCtx.TransLog.Add(new TransLog() { Token = DafoTypes.token, Kind = "After", JsonStr = jsonAfter, CreateTime = DateTime.Now });
                ontoCtx.SaveChanges();
                ontoCtx.Dispose();
            }
            return sqlQuery;
        }

        public string SqlToHTML(string sqlQuery)
        {
            //string sqlHTML = "<p>"+sqlQuery.Replace("\n","</p><p>")+"</p>";
            string sqlHTML = "<p>" + sqlQuery.Replace("\n", "<br/>") + "</p>";
            return sqlHTML;
        }

        public void createTreeExp(DafoTypes.ExpNode parentNode, string parentId, string parentAndOr, 
                                  List<NodeType> currNodeList, string variable, string variable1)
        {
            if (parentId == "#")
            {
                for (int i = 0; i < nodesJSON.Count(); i++)
                {
                    NodeType node = nodeList[i];// w calym zbiorze
                    if (node.parent == "#")
                    {
                        parentId = node.id;
                        if (node.attr.Contains("and")) {
                            parentAndOr = "AND";
                        }
                        else
                        {
                            parentAndOr = "OR";
                        }
                        break;
                    }
                }
            }
            List<NodeType> newNodeList = new List<NodeType>();
            for (int i = 0; i < currNodeList.Count(); i++)
            {
                NodeType node = currNodeList[i];
                if (node.parent == parentId)
                {
                    newNodeList.Add(node);
                }
                    
            }
            if (newNodeList.Count() > 0)
            {
                variable = variable1;
                if (newNodeList[0].attr.Contains("const") && newNodeList.Count() > 1)
                {
                    string anytext = "ANY (";
                    if (parentNode.Parent.Flag.Contains("and"))
                    {
                        anytext = "'ALL(";
                    }
                    for (int i = 0; i< newNodeList.Count(); i++)
                    {
                        if (i > 0)
                        {
                            anytext += ",";
                        }
                        anytext += "'"+newNodeList[i].text+"'";
                    }
                    anytext += ")";
                    NodeType anynode = new NodeType();
                    anynode = newNodeList[0];
                    anynode.text = anytext;
                    newNodeList.Clear();
                    newNodeList.Add(anynode);
                }
                InsertChildren(parentNode, parentAndOr, newNodeList, variable, variable1);
            }
            else
            {
                //usunac niepotrzebny lisc
                parentNode.Parent.ChildNode = null;
            }
        }

        public void InsertChildren(DafoTypes.ExpNode currNode, string andOr, List<NodeType> currNodeList, string variable,string variable1)
        {
            if (currNodeList.Count() == 1)
            {

                if (currNodeList[0].attr.Contains("excl"))
                {
                    DafoTypes.ExpNode notNode = new DafoTypes.ExpNode();
                    currNode.NodeType = "NOT";
                    currNode.PropagationPath = "";
                    DafoTypes.ExpNode newcurrNode = new DafoTypes.ExpNode();
                    newcurrNode.Parent = currNode;
                    currNode.ChildNode = newcurrNode;
                    currNode = newcurrNode;
                }
                if (currNodeList[0].text.Contains("[ count()"))
                {
                    int startCount = currNodeList[0].text.IndexOf("[ count()");
                    string count = currNodeList[0].text.Substring(startCount);
                    string nameTxt = currNodeList[0].text.Substring(0, startCount - 1);
                    List<String> components = new List<String>();
                    components = count.Split(' ').ToList();
                    currNodeList[0].text = nameTxt;
                    currNode.countColumn = nameTxt;
                    currNode.countComp = components[2];
                    currNode.countNumber = components[3];
                    var countcond = "count() " + currNode.countComp + " " + currNode.countNumber;
                    currNode.countCond = "in:" + countcond;
                    // to samo do Parent 08.2019
                    currNode.Parent.countColumn = nameTxt;
                    currNode.Parent.countComp = components[2];
                    currNode.Parent.countNumber = components[3];
                    currNode.Parent.countCond = "start:" + countcond;

                }
                DafoTypes.ExpNode parent = currNode.Parent;
                if (currNodeList[0].attr.Contains("up")) {
                    while (parent != null)
                    {
                        if (parent.JSONId == currNodeList[0].parent)
                        {
                            variable = parent.VarName1;
                            break;
                        }

                        parent = parent.Parent;
                    }
                }
                currNode.Name = currNodeList[0].text;
                currNode.Flag = currNodeList[0].attr;
                currNode.JSONId = currNodeList[0].id; // id wierzcholka JSON
                currNode.JSONParentId = currNodeList[0].parent;
                currNode.PropagationPath = "";
                currNode.Flag = "";
                if (currNodeList[0].attr.Contains("up"))
                {
                    currNode.NodeType = "UP";
                    currNode.VarName = variable;
                    if (parent != null && parent.countCond != null && parent.countCond.Contains("in:count()"))
                    {
                        currNode.countColumn = parent.countColumn;
                        currNode.countComp = parent.countComp;
                        currNode.countNumber = parent.countNumber;
                        var countcond = "count(" + currNode.VarName + ") " + currNode.countComp + " " + currNode.countNumber;
                        string countvar= parent.Parent.VarName + "_" + currNode.VarName + "_count";
                        //currNode.countCond = "end:" + countcond;
                        //currNode.aggStack = "end_" + countvar;
                        parent.countCond = "end:" + countcond;
                        parent.aggStack = "end_" + countvar;
                        parent.Parent.countCond = "start:" + countcond;
                        parent.Parent.aggStack = "start_" + countvar;
                    }
                } else if (currNodeList[0].attr.Contains("df") || currNodeList[0].attr.Contains("dm") || currNodeList[0].attr.Contains("of") || currNodeList[0].attr.Contains("om"))
                {
                    currNode.NodeType = "BP";
                    currNode.VarName = variable;
                    variable1 = "x" + (++variableNo).ToString();
                    currNode.VarName1 = variable1;// gvariable1;

                } else if (currNodeList[0].attr.Contains("const"))
                {
                    currNode.NodeType = "EQ";
                    currNode.VarName = variable1;
                }
                andOr = "OR";
                if (currNodeList[0].attr.Contains("and"))
                {
                    andOr = "AND";
                }
                DafoTypes.ExpNode parentNode = new DafoTypes.ExpNode();
                parentNode.Parent = currNode;
                currNode.ChildNode = parentNode;
                createTreeExp(parentNode,currNodeList[0].id, andOr, nodeList, variable, variable1);
            }
            else
            {
                DafoTypes.ExpNode andOrNode = currNode;
                List<NodeType> currNodeListLeft = new List<NodeType>();
                currNodeListLeft.Add(currNodeList[0]);
                List<NodeType> currNodeListRight = new List<NodeType>();
                for (int i = 1; i < currNodeList.Count(); i++)
                {
                    currNodeListRight.Add(currNodeList[i]);
                }
                DafoTypes.ExpNode leftNode = new DafoTypes.ExpNode();
                DafoTypes.ExpNode rightNode = new DafoTypes.ExpNode();
                andOrNode.LeftNode = leftNode;
                andOrNode.RightNode = rightNode;
                leftNode.Parent = andOrNode;
                rightNode.Parent = andOrNode;
                andOrNode.NodeType = andOr;
                andOrNode.Flag = andOr;
                andOrNode.PropagationPath = "";
                InsertChildren(leftNode, andOr, currNodeListLeft, variable, variable1);
                if (currNodeListRight.Count() >= 1)
                {
                    DafoTypes.ExpNode aright1 = new DafoTypes.ExpNode();
                    andOrNode.RightNode = rightNode;
                }
                InsertChildren(rightNode, andOr, currNodeListRight, variable, variable1);
            }
        }

        //===========================================================================================================
        // Rewriting
        //=====================================

        public Boolean isIntenc(String name)
        {
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
            String nameKind = (from t in ontoCtx.Sigma
                               where t.Name == name
                               select t.Kind).FirstOrDefault();
            ontoCtx.Dispose();
            if (nameKind == "I")
                return true;
            else
                return false;
        }

        public void SetTranslationInformation(DafoTypes.ExpNode node)
        {
            if (node == null)
            {
                return;
            }
            if (node.NodeType == "UP" || node.NodeType == "BP")
            {
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var MapInfo = (from t in ontoCtx.Sigma
                               where t.Name == node.Name
                               select new { t.TabMap, t.DomMap, t.RngMap, t.FuncType }).FirstOrDefault();
                ontoCtx.Dispose();
                int inversion = 0;
                node.Map_TabMap = MapInfo.TabMap;
                node.Map_DomMap = MapInfo.DomMap;
                node.Map_RngMap = MapInfo.RngMap;
                node.Trans_Alias1 = node.VarName;
                node.Trans_Alias2 = node.VarName1;
                node.Trans_Col1 = MapInfo.DomMap;
                node.Trans_Col2 = MapInfo.RngMap;
                if (node.NodeType == "BP")
                {
                    DafoSqlQuery dsq = new DafoSqlQuery();
                    inversion = dsq.StateOfInversion(node);
                    if (inversion == 1)
                    {
                        node.Trans_Alias1 = node.VarName1;
                        node.Trans_Alias2 = node.VarName;
                        node.Trans_Col1 = MapInfo.RngMap;
                        node.Trans_Col2 = MapInfo.DomMap;
                    }
                }
            }
            if (node.ChildNode != null)
            {
                SetTranslationInformation(node.ChildNode);
            }
            if (node.LeftNode != null)
            {
                SetTranslationInformation(node.LeftNode);
                SetTranslationInformation(node.RightNode);
            }
        }
        public void setCountStack(DafoTypes.ExpNode node, string startVar, string endVar) //12.08.2019
        {
            if (node == null)
            {
                return;
            }
            if (node.aggStack != null && node.NodeType == "UP" && startVar == "" && endVar =="")
            {
                string countvar = node.aggStack.Substring(6);
                string[] aggStackList = node.aggStack.Split('_');
                startVar = aggStackList[1];
                endVar = aggStackList[2];
                DafoTypes.ExpNode childNode = node.ChildNode;
                while (childNode != null)
                {
                    if (childNode.NodeType == "BP")
                    {
                        if (childNode.VarName==startVar && childNode.VarName1 == endVar || childNode.VarName1 == startVar && childNode.VarName == endVar)
                        {
                            childNode.aggStack = "end_" + countvar;
                            break;
                        } else if (childNode.VarName == startVar || childNode.VarName1 == startVar)
                        {
                            childNode.aggStack = "start_" + countvar;
                            childNode = childNode.ChildNode;
                        } else if (childNode.VarName == endVar || childNode.VarName1 == endVar)
                        {
                            childNode.aggStack = "end_" + countvar;
                            break;
                        }
                        else
                        {
                            childNode.aggStack = "in_" + countvar;
                            childNode = childNode.ChildNode;
                        }
                    }
                    else
                    {
                        childNode = childNode.ChildNode;
                    }
                }
            }
        }

        public string firstCycleVar = "";
        public string leftCycleVar = "";
        public string lastCycleVar = "";
        public string rightCycleVar = "";
        public string aliasCycle = "";
        public string cyclePath = "";

        public void setCycleStack(DafoTypes.ExpNode node) //01.09.2019
        {
            if (node == null)
            {
                return;
            }
            if (node.ChildNode == null && node.NodeType == "EQ" && node.Name.Substring(0, 1) == "@")
            {
                if (firstCycleVar == "")
                {
                    firstCycleVar = node.Parent.VarName;
                    leftCycleVar = node.VarName;
                }
                else
                {
                    lastCycleVar = node.Parent.VarName;
                    rightCycleVar = node.VarName;
                    aliasCycle = firstCycleVar + "_" + lastCycleVar + "_cycle";
                    node.cyclStack = aliasCycle;
                    DafoTypes.ExpNode parNode = node.Parent;
                    while (parNode != null)
                    {
                        parNode.cyclStack = "in_"+aliasCycle;
                        if (parNode.NodeType == "UP" && parNode.VarName == firstCycleVar)
                        {
                            parNode.cyclEq = "[" + firstCycleVar + " = " + lastCycleVar + "]";
                            //parNode.cyclStack = "start_" + aliasCycle;
                            break;
                        } else
                        {
                            parNode = parNode.Parent;
                        }
                    }
                }
            }
            if (node.ChildNode != null)
            {
                setCycleStack(node.ChildNode);
            }
            if (node.LeftNode != null)
            {
                setCycleStack(node.LeftNode);
                setCycleStack(node.RightNode);
            }
        }

        public void delCycleVar(DafoTypes.ExpNode node) //01.09.2019
        {
            if (node == null)
            {
                return;
            }
            if (node.ChildNode == null && node.Parent != null && node.NodeType == "EQ" && node.Name.Substring(0, 1) == "@"
                && node.Parent.VarName == firstCycleVar)// pierwszy
            {
                DafoTypes.ExpNode parNode = node.Parent;// _Id_C
                parNode = parNode.Parent;// AND
                DafoTypes.ExpNode delNode = parNode;
                if (parNode.NodeType == "AND")
                {
                    DafoTypes.ExpNode rightNode = parNode.RightNode;// authorOf
                    parNode = parNode.Parent;// Person
                    delNode.Parent = null;
                    parNode.ChildNode = rightNode;
                    rightNode.Parent = parNode;
                    rightNode.cyclStack = "start_" + rightNode.cyclStack.Substring(3);
                    parNode.cyclStack = "start_" + parNode.cyclStack.Substring(3);
                }
            }
            if (node.ChildNode == null && node.Parent != null && node.NodeType == "EQ" && node.Name.Substring(0, 1) == "@"
                && node.Parent.VarName == lastCycleVar)// ostatni
            {
                DafoTypes.ExpNode parNode = node.Parent;// _Id_C
                parNode = parNode.Parent;
                DafoTypes.ExpNode delNode = parNode;
                if (parNode.NodeType == "AND")
                {
                    DafoTypes.ExpNode rightNode = parNode.RightNode;
                    parNode = parNode.Parent;
                    delNode.Parent = null;
                    parNode.ChildNode = rightNode;
                    rightNode.Parent = parNode;
                    parNode.cyclStack = "end_" + parNode.cyclStack;
                }
                else
                {
                    parNode.ChildNode = null;
                    parNode.cyclStack = "end_" + parNode.cyclStack.Substring(3);
                }
            }
            if (node.ChildNode != null)
            {
                delCycleVar(node.ChildNode);
            }
            if (node.LeftNode != null)
            {
                delCycleVar(node.LeftNode);
                delCycleVar(node.RightNode);
            }
        }

        public void RewriteQuery(DafoTypes.ExpNode node)
        {
            if (node.NodeType == "EQ")
            {
                //DafoTypes.isRewritten = false;
                return;
            }
            if (isIntenc(node.Name))
            {
                Rewrite(node);
                DafoTypes.isRewritten = true;
            }
            if (node.ChildNode != null)
                RewriteQuery(node.ChildNode);
            if (node.LeftNode != null)
                RewriteQuery(node.LeftNode);
            if (node.RightNode != null)
                RewriteQuery(node.RightNode);
        }

        private void Rewrite(DafoTypes.ExpNode node)
        {
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var RWdataChain = (from t in ontoCtx.Chain
                              where t.Bname3 == node.Name
                              join r in ontoCtx.Rng
                              on t.Bname1 equals r.Bname
                              select new { RWRng = r.Uname, RWBp1 = t.Bname1, RWBp2 = t.Bname2 }).FirstOrDefault();
                if (RWdataChain != null)
                {
                    ontoCtx.Dispose();
                    RewriteChain(node, RWdataChain.RWRng, RWdataChain.RWBp1, RWdataChain.RWBp2);
                    return;
                }
                string bpNameInv = (from t in ontoCtx.Inv
                                 where t.Bname2 == node.Name
                                 select t.Bname1).FirstOrDefault();
                if (bpNameInv != null)
                {
                    ontoCtx.Dispose();
                    RewriteInv(node, bpNameInv);
                    return;
                }
                string bpNameProp = (from t in ontoCtx.SubProp
                                 where t.Bname1 == node.Name
                                 select t.Bname2).FirstOrDefault();
                if (bpNameProp != null)
                {
                    ontoCtx.Dispose();
                    RewriteSubProp(node, bpNameProp);
                    return;
                }
                var RWdataSpec1 = (from t in ontoCtx.Spec1
                              where t.Uname == node.Name
                              join d in ontoCtx.Dom
                              on t.Bname equals d.Bname
                              select new { RWDom = d.Uname, RWBp = t.Bname, RWConst = t.Const }).FirstOrDefault();
                if (RWdataSpec1 != null)
                {
                    ontoCtx.Dispose();
                    RewriteSpec1(node, RWdataSpec1.RWDom, RWdataSpec1.RWBp, RWdataSpec1.RWConst);
                    return;
                }
                var RWdataSpec2 = (from t in ontoCtx.Spec2
                              where t.Uname2 == node.Name
                              join d in ontoCtx.Dom
                              on t.Bname equals d.Bname
                              select new { RWDom = d.Uname, RWBp = t.Bname, RWUp = t.Uname1 }).FirstOrDefault();
                if (RWdataSpec2 != null)
                {
                    ontoCtx.Dispose();
                    RewriteSpec2(node, RWdataSpec2.RWDom, RWdataSpec2.RWBp, RWdataSpec2.RWUp);
                    return;
                }
        }

        private void RewriteSubProp(DafoTypes.ExpNode node, string bpName)
        {
            node.Name = bpName;
        }

        private void RewriteInv(DafoTypes.ExpNode node, string bpName)
        {

            node.Name = bpName;
            string pom = node.VarName;
            node.VarName = node.VarName1;
            node.VarName1 = pom;
            if (node.countColumn != null && node.aggStack != null)
            {
                string aggStackVar = node.aggStack.Substring(3);
                ReplaceDownCountColumn(node,node.countColumn, bpName,aggStackVar);
                node.countColumn = bpName;
                DafoTypes.ExpNode nodePop = node.Parent;
                while (nodePop != null && nodePop.aggStack != null && nodePop.aggStack.Contains(aggStackVar))
                {
                    nodePop.countColumn = bpName;
                    //nodePop.countComp = node.countComp; // 08.2019"";//node.countComp;
                    //nodePop.countNumber = node.countNumber;//.ToString();
                    nodePop = nodePop.Parent;
                }
            }
        }

        private void ReplaceDownCountColumn(DafoTypes.ExpNode node, string countColumn, string bpName, string aggStackVar)
        {
            if (node == null || node.aggStack == null)
            {
                return;
            }
            if (node.aggStack.Contains(aggStackVar))
            {
                node.countColumn = bpName;
            }
            if (node.ChildNode != null)
            {
                ReplaceDownCountColumn(node.ChildNode, countColumn, bpName, aggStackVar);
            }
            if (node.LeftNode != null)
            {
                ReplaceDownCountColumn(node.LeftNode, countColumn, bpName, aggStackVar);
                ReplaceDownCountColumn(node.RightNode, countColumn, bpName, aggStackVar);
            }
        }

        private void RewriteChain(DafoTypes.ExpNode node, string RWRng, string RWBp1, string RWBp2)
        {
            DafoTypes.ExpNode prevNode = node.Parent;
            //if ("AND,OR,NOT".Contains(node.Parent.NodeType))
            //{
            //    prevNode = prevNode.Parent;
            //}
            //if (prevNode != null && prevNode.countColumn != null && node.countColumn == prevNode.countColumn && prevNode.aggStack == null)
            //{
            //    prevNode.aggStack = "start_" + node.VarName + "_" + node.VarName1 + "_c";//12.08.2019
            //}
            node.Name = RWBp1;
            node.Path = RWBp1;
            string popVarName1 = node.VarName1;
            int popValIndex1 = node.ValIndex1;
            DafoTypes.ExpNode popChildNode = node.ChildNode;
            variableNo++;
            string varName1 = "x" + variableNo.ToString();
            int valIndex1 = variableNo;
            node.VarName1 = varName1;
            node.ValIndex1 = valIndex1;
            DafoTypes.ExpNode bp1Node = node;
            DafoTypes.VarTab elTab = new DafoTypes.VarTab(varName1, "");
            //utworzenie UP dla RWRng
            DafoTypes.ExpNode upNode = new DafoTypes.ExpNode("UP", node, varName1, valIndex1, "", 0, RWRng, RWRng, null, null, null);
            upNode.countColumn = node.countColumn; //12.08.2019
            //upNode.countComp = node.countComp;
            //upNode.countNumber = node.countNumber;
            node.ChildNode = upNode;
            ExpNodeList.Add(upNode);
            //tworzenie dla RWBp2
            DafoTypes.ExpNode bpNode = new DafoTypes.ExpNode("BP", upNode, varName1, valIndex1, popVarName1, popValIndex1, RWBp2, RWBp2, popChildNode, null, null);
            bpNode.countColumn = node.countColumn;
            //bpNode.countComp = node.countComp;
            //bpNode.countNumber = node.countNumber;
            ExpNodeList.Add(bpNode);
            upNode.ChildNode = bpNode;
            if (popChildNode != null) // 2017
                popChildNode.Parent = bpNode;
            bpNode.countColumn = bp1Node.countColumn;
            //bpNode.countComp = bp1Node.countComp;
            //bpNode.countNumber = bp1Node.countNumber;
        }

        private void RewriteSpec1(DafoTypes.ExpNode node, string RWDom, string RWBp, string RWConst)
        {
            //if (node.ChildNode != null && node.ChildNode.countColumn != null
            //       && node.countColumn == node.ChildNode.countColumn && node.ChildNode.aggStack == null)
            //{
            //    node.aggStack = "start_" + node.ChildNode.VarName + "_" + node.ChildNode.VarName1 + "_c";//12.08.2019
            //}
            node.Name = RWDom;
            node.Path = RWDom;
            //utworzenie nowego AND i BP dla RWBp
            string varName = node.VarName;
            int valIndex = node.ValIndex;
            variableNo++;
            string varName1 = "x" + variableNo.ToString();
            int valIndex1 = variableNo;
            DafoTypes.VarTab elTab = new DafoTypes.VarTab(varName1, "");
            DafoTypes.ExpNode bpNode = new DafoTypes.ExpNode("BP", null, varName, valIndex, varName1, valIndex1, RWBp, RWBp, null, null, null);
            ExpNodeList.Add(bpNode);
            if (node.ChildNode != null)
            {
                DafoTypes.ExpNode logNode = new DafoTypes.ExpNode("AND", node, "", 0, "", 0, "", "", null, bpNode, node.ChildNode);
                node.ChildNode.Parent = logNode;
                node.ChildNode = logNode;
                bpNode.Parent = logNode;
                //logNode.aggStack = logNode.Parent.aggStack; //08.2019
                logNode.countColumn = logNode.Parent.countColumn; //08.2019
                ExpNodeList.Add(logNode);
            }
            else
            {
                node.ChildNode = bpNode;
                bpNode.Parent = node;
            }
            //utworzenie nowego Eq dla RWConst
            varName = bpNode.VarName1;
            valIndex = bpNode.ValIndex1;
            DafoTypes.ExpNode eqNode = new DafoTypes.ExpNode("EQ", bpNode, varName, valIndex, "", 0, RWConst, RWConst, null, null, null);
            bpNode.ChildNode = eqNode;
            ExpNodeList.Add(eqNode);

        }
        private void RewriteSpec2(DafoTypes.ExpNode node, string RWDom, string RWBp, string RWUp)
        {
            //if (node.ChildNode != null && node.ChildNode.countColumn != null
            //    && node.countColumn == node.ChildNode.countColumn && node.ChildNode.aggStack == null)
            //{
            //    node.aggStack = "start_" + node.ChildNode.VarName + "_" + node.ChildNode.VarName1 + "_c";//12.08.2019
            //}
            node.Name = RWDom;
            node.Path = RWDom;
            //utworzenie nowego AND i BP dla RWBp
            string varName = node.VarName;
            int valIndex = node.ValIndex;
            variableNo++;
            string varName1 = "x" + variableNo.ToString();
            int valIndex1 = variableNo;
            DafoTypes.VarTab elTab = new DafoTypes.VarTab(varName1, "");
            variableNo++;
            DafoTypes.ExpNode bpNode = new DafoTypes.ExpNode("BP", null, varName, valIndex, varName1, valIndex1, RWBp, RWBp, null, null, null);
            ExpNodeList.Add(bpNode);
            if (node.ChildNode != null)
            {
                DafoTypes.ExpNode logNode = new DafoTypes.ExpNode("AND", node, "", 0, "", 0, "", "", null, bpNode, node.ChildNode);
                node.ChildNode.Parent = logNode;
                node.ChildNode = logNode;
                bpNode.Parent = logNode;
                //logNode.aggStack = logNode.Parent.aggStack; //08.2019
                logNode.countColumn = logNode.Parent.countColumn; //08.2019
                ExpNodeList.Add(logNode);
            }
            else
            {
                node.ChildNode = bpNode;
                bpNode.Parent = node;
            }
            //utworzenie nowego UP dla RWUp
            varName = bpNode.VarName1;
            valIndex = bpNode.ValIndex1;
            DafoTypes.ExpNode upNode = new DafoTypes.ExpNode("UP", bpNode, varName, valIndex, "", 0, RWUp, RWUp, null, null, null);
            bpNode.ChildNode = upNode;
            ExpNodeList.Add(upNode);
        }

        //=========================================================================
        // // JSON of FO queries
        //=========================================================================

        public int nodeIdx = 0;
        public string json = "";
        public string FOtoJSON(DafoTypes.ExpNode rootExp)
        {
            nodeIdx = 0;
            json = "";
            nodeFOtoJSON(rootExp, "#");
            json = "[" + json + "]";
            //JObject treeJSON = JObject.Parse(json);
            //JArray nodesJSON = (JArray)treeJSON["tree"];
            return json;
        }

        
        public void nodeFOtoJSON(DafoTypes.ExpNode node, string parent)
        {
            string nodeId = nodeIdx++.ToString();
            string txt = "";
            Boolean foundBP = false;
            if (node.Name == null || node.Name == "")
            {
                txt = node.NodeType;
            }
            else
            {
                if (node.NodeType == "BP")
                {
                    txt += node.Name + "(" + node.VarName + "," + node.VarName1 + ")";
                    //if (node.countColumn != null && node.countColumn != "")
                    //{
                    //    txt += " [count(" + node.VarName1 + ") " + node.countComp + " " + node.countNumber + "]";
                    //}
                }
                else
                {
                    //if (node.NodeType == "UP")
                    //{
                    //    txt += node.Name + "(" + node.VarName + ")";
                    //    if (node.countColumn != null && node.countColumn != "")
                    //    {
                    //        if (!foundBP)
                    //        {
                    //            if (node.aggStack != null) // for rewritten: after
                    //            {
                    //                string[] aggstack = node.aggStack.Split('_');
                    //                if (node.VarName == aggstack[1])
                    //                {
                    //                    txt += " [count(" + aggstack[2] + ") " + node.countComp + " " + node.countNumber + "]";
                    //                }
                    //                else
                    //                {
                    //                    txt += " [count(" + aggstack[1] + ") " + node.countComp + " " + node.countNumber + "]";
                    //                }
                    //                foundBP = true;
                    //            }
                    //            else // for unrewritten: before
                    //            {
                    //                if (node.ChildNode != null && node.VarName == node.ChildNode.VarName)
                    //                {
                    //                    txt += " [count(" + node.ChildNode.VarName1 + ") " + node.countComp + " " + node.countNumber + "]";
                    //                    foundBP = true;
                    //                }
                    //                if (node.ChildNode != null && node.VarName == node.ChildNode.VarName1)
                    //                {
                    //                    txt += " [count(" + node.ChildNode.VarName + ") " + node.countComp + " " + node.countNumber + "]";
                    //                    foundBP = true;
                    //                }
                    //            }
                    //        }
                    //    }
                    //}
                    if (node.NodeType == "UP")
                    {
                        txt += node.Name + "(" + node.VarName + ")";
                        if (node.countCond != null && node.countCond.Contains("start:"))
                        {
                            txt += " [" + node.countCond.Substring(6) + "]";
                        }
                        if (node.cyclEq != null && node.cyclEq != "")
                        {
                            txt += " " + node.cyclEq;
                        }
                    }
                    else
                    {
                        if (node.NodeType == "EQ")
                        {
                            txt += node.VarName + " = " + node.Name.Replace("'", "");
                        }
                    }
                }
            }
            if (json != "")
            {
                json += ",";
                ;
            }
            json += "{'id':'" + nodeId + "','text':'" + txt.Trim() + "','parent':'" + parent + "'}";
            if (node.ChildNode != null)
            {
                nodeFOtoJSON(node.ChildNode, nodeId);
            }
            else if (node.LeftNode != null)
            {
                nodeFOtoJSON(node.LeftNode, nodeId);
                nodeFOtoJSON(node.RightNode, nodeId);
            }
        }

        //===========================================================================================================
        // Inversion for obtaining values of attribute and for FOCUS ON
        //===========================================================================================================

        public JArray InverseTreeArray(JArray treeArray, string classId)
        {
            List<NodeType> treeArrayList = new List<NodeType>();
            for (int i = 0; i < treeArray.Count(); i++)
            {
                NodeType node = treeArray[i].ToObject<NodeType>();
                treeArrayList.Add(node);
            }
            List<NodeType> pathList = new List<NodeType>();
            int lastIdx = 0;
            for (int i = 0; i < treeArray.Count(); i++)
            {
                if (treeArrayList[i].id == classId)
                {
                    lastIdx = 0;
                    NodeType nodeLast = treeArrayList[i];
                    pathList.Add(nodeLast);
                    break;
                }
            }
            string seekId = pathList[0].parent;
            while (seekId != "#")
            {
                for (int i = 0; i < treeArray.Count(); i++)
                {
                    if (treeArrayList[i].id == seekId)
                    {
                        NodeType nodeCurr = treeArrayList[i];
                        if (nodeCurr.parent != "#")
                        {
                            pathList.Add(nodeCurr);
                            lastIdx++;
                        }
                        seekId = nodeCurr.parent;
                        break;
                    }
                }
            }// w pathList jest sciezka do wierzcholka (bez root)
            //lastIdx = treeArray.Count()-1; ostatni index pathList
            int currIdx = 0;
            List<NodeType> invList = new List<NodeType>();
            NodeType nodeProp = treeArrayList[0];// root
            invList.Add(nodeProp);
            NodeType nodeClass = pathList[0];// treeArray[lastIdx].ToObject<NodeType>();
            nodeClass.parent = invList[0].id; //szukany wskazuje na root-a
            invList.Add(nodeClass);
            currIdx = 1;
            for (int i = 1; i < lastIdx; i = i + 2)
            {
                nodeProp = pathList[i]; //treeArray[i].ToObject<NodeType>();
                nodeProp.parent = invList[currIdx].id;
                nodeProp.text = GetInversion(nodeProp.text);
                invList.Add(nodeProp);
                currIdx++;
                nodeClass = pathList[i + 1]; //treeArray[i - 1].ToObject<NodeType>();
                nodeClass.parent = invList[currIdx].id;
                invList.Add(nodeClass);
                currIdx++;
            }
            for (var k = 0; k < invList.Count(); k++)
            {
                for (int i = 0; i < treeArray.Count(); i++)
                {
                    if (treeArrayList[i].id == invList[k].id)
                    {
                        treeArray[i]["id"] = invList[k].id;
                        treeArray[i]["text"] = invList[k].text;
                        treeArray[i]["parent"] = invList[k].parent;
                        treeArray[i]["attr"] = invList[k].attr;
                        break;
                    }
                }
            }
            return treeArray;
        }

        public string GetInversion(string bname)
        {
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
            string bnameInv = "";
            bnameInv = (from t in ontoCtx.Inv
                        where t.Bname1 == bname
                        select t.Bname2).FirstOrDefault();
            if (bnameInv == null || bnameInv == "")
            {
                bnameInv = (from t in ontoCtx.Inv
                            where t.Bname2 == bname
                            select t.Bname1).FirstOrDefault();
            }
            ontoCtx.Dispose();
            return bnameInv;
        }

        public string TreeArrayToStr(JArray treeArrayInv)
        {
            IList collection = (IList)treeArrayInv;
            //var nodeList = new List<string>();
            string treeStr = "[";
            for (int i = 0; i < collection.Count; i++)
            {
                //nodeList.Add(collection[i].ToString());
                if (treeStr.Length > 5)
                {
                    treeStr += ",";
                }
                string elemStr = collection[i].ToString();
                string[] nodeFields = elemStr.Split(',');
                string[] attr = nodeFields[3].Split(':');
                string iconStr = " ";
                if (attr[1].Contains("and"))
                {
                    iconStr = "AndIcon";
                }
                if (attr[1].Contains("or"))
                {
                    iconStr = "OrIcon";
                }
                string li_attr = "\"li_attr\":{\"class\":" + attr[1] + ",\"icon\":\"" + iconStr + "\"" + ", \"state\" : {\"selected\" : false, \"opened\" : true, \"checked\" : true}}";
                treeStr += nodeFields[0] + "," + nodeFields[1] + "," + nodeFields[2] + "," + li_attr;
            }
            return treeStr + "]";
        }


        //===========================================================================================================
        // Explore for obtaining values of attribute and for FOCUS ON
        //===========================================================================================================

        public String ExtendTreeArray(JArray treeArray, string exploreId, string exploreName)
        {
            List<NodeType> treeArrayList = new List<NodeType>();
            List<NodeType> treeArrayListExpand = new List<NodeType>();
            treeArrayListExpand.Clear();
            for (int i = 0; i < treeArray.Count(); i++)
            {
                NodeType node = treeArray[i].ToObject<NodeType>();
                treeArrayList.Add(node);
            }
            string treeStrStart = "{\"tree\":[";
            for (int i = 0; i < treeArrayList.Count(); i++)
            {
                if (i > 0)
                {
                    treeStrStart += ",";
                }
                treeStrStart += "{\"id\":\"" + treeArrayList[i].id + "\",\"text\":\"" + treeArrayList[i].text + "\",\"parent\":\"" + treeArrayList[i].parent + "\",\"attr\":\""
                        + treeArrayList[i].attr + "\"}";
            }
            int nodeId = 1;
            // do exploreId bede dodawal wszystkie mozliwe pary (P,C)
            // znajduje wszystkie mozliwe property P
            //select D.BName
            //from Dom D, Rng R,  mv_MaxSuperClasses M
            //where M.UName = 'PUTAuthor' and D.UName = M.UNameMax and D.BName = R.BName and R.UName <> 'String'
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
            List<string> propList = (from d in ontoCtx.Dom
                                     from r in ontoCtx.Rng
                                     from m in ontoCtx.MvMaxSuperClasses
                                     where m.Uname == exploreName && d.Uname == m.UnameMax && d.Bname == r.Bname && r.Uname != "String"
                                     select d.Bname).ToList();
            foreach (string propName in propList)
            {
                string propId = exploreId + "_" + nodeId++.ToString();
                NodeType propNode = new NodeType();
                propNode.id = propId;
                propNode.text = propName;
                propNode.parent = exploreId;
                propNode.attr = "or om incl";
                treeArrayListExpand.Add(propNode);
                //"{\"id\":\"" + propId + "\",\"text\":\"" + propName + "\",\"parent\":\""+exploreId+"\",\"attr\":\"or dm incl\"}";
                //propJson += "\"li_attr\":{\"class\":\"or om incl\"}," + "\"icon\":\"OrIcon\"," + "\"state\" : {\"selected\" : false, \"opened\" : true, \"checked\" : true}}";
                //select  M2.UName,M2.Level
                //from Dom D, Rng R, mv_MaxSuperClasses M1, mv_MaxSuperClasses M2
                //where D.BName = 'authorOf' and M1.UName = 'PUTAuthor' and D.UName = M1.UNameMax and D.BName = R.BName
                //and M2.UNameMax = R.UName
                //order by M2.Level,M2.UName
                var classList = (from d in ontoCtx.Dom
                                            from r in ontoCtx.Rng
                                            from m1 in ontoCtx.MvMaxSuperClasses
                                            from m2 in ontoCtx.MvMaxSuperClasses
                                            where d.Bname == propName && m1.Uname == exploreName && d.Uname == m1.UnameMax && d.Bname == r.Bname && m2.UnameMax == r.Uname
                                            select new { Uname = m2.Uname, Level = m2.Level }).OrderBy(x => x.Level).ThenBy(x => x.Uname);
                int sumAnswerNumber = 0;
                foreach (var cStruk in classList)// przegotowanie zapytania SQL
                {
                    string className = cStruk.Uname;
                    string classId = propId + "_" + nodeId++.ToString();
                    NodeType classNode = new NodeType();
                    classNode.id = classId;
                    classNode.text = className;
                    classNode.parent = propId;
                    classNode.attr = "andexpl up incl";
                    //treeArrayListCount.Add(classNode);
                    string treeStrCount = treeStrStart+","
                        + "{\"id\":\"" + propNode.id + "\",\"text\":\"" + propNode.text + "\",\"parent\":\""
                            + propNode.parent + "\",\"attr\":\""+ propNode.attr + "\"},"
                        +"{\"id\":\"" + classNode.id + "\",\"text\":\"" + classNode.text + "\",\"parent\":\""
                            + classNode.parent + "\",\"attr\":\"" + classNode.attr + "\"}" + "]}";

                    //for (int i = 0; i < treeArrayListCount.Count(); i++)
                    //{
                    //    treeStrCount += "{\"id\":\"" + treeArrayListCount[i].id + "\",\"text\":\"" + treeArrayListCount[i].text + "\",\"parent\":\"" 
                    //        + treeArrayListCount[i].parent + "\",\"attr\":\""
                    //        + treeArrayListCount[i].attr + "\"}";
                    //}
                    //treeStrCount += "]}";
                    JObject treeJSON = JObject.Parse(treeStrCount);
                    JArray exploreTreeArray = (JArray)treeJSON["tree"];
                    DafoTypes.ExpNode rootExp = new DafoTypes.ExpNode();
                    string sqlQuery = CreateQueryExp(exploreTreeArray, rootExp, "explore");
                    DAFO_02Context dbCtx = new DAFO_02Context();
                    var ansListId = dbCtx.MvAnswerId.FromSql(sqlQuery).ToList();
                    int answerNumber = ansListId.Count();
                    sumAnswerNumber += answerNumber;
                    if (answerNumber > 0)
                    {
                        //classNode.text += " [number of connected "+exploreName+ " instances: " + answerNumber.ToString() + "]";
                        //classNode.text += " [# of connected " + exploreName + "'s: " + answerNumber.ToString() + "]";
                        classNode.text += " ["+ answerNumber.ToString() + " of connected " + exploreName+"]";
                        treeArrayListExpand.Add(classNode);
                    }
                }
                if (sumAnswerNumber == 0)
                {
                    treeArrayListExpand.Remove(treeArrayListExpand[treeArrayListExpand.Count() - 1]);
                }
            }
            // to string
            IList collection = (IList)treeArray;
            string treeStr = "[";
            for (int i = 0; i < collection.Count; i++) // to co bylo
            {
                //nodeList.Add(collection[i].ToString());
                if (treeStr.Length > 5)
                {
                    treeStr += ",";
                }
                string elemStr = collection[i].ToString();
                string[] nodeFields = elemStr.Split(',');
                string[] attr = nodeFields[3].Split(':');
                string iconStr = " ";
                if (attr[1].Contains("and"))
                {
                    iconStr = "AndIcon";
                }
                if (attr[1].Contains("or"))
                {
                    iconStr = "OrIcon";
                }
                string li_attr = "\"li_attr\":{\"class\":" + attr[1] + ",\"icon\":\"" + iconStr + "\"" + ", \"state\" : {\"selected\" : false, \"opened\" : true, \"checked\" : true}}";
                treeStr +=nodeFields[0] + "," + nodeFields[1] + "," + nodeFields[2] + "," + li_attr;
            }
            // do tego dodactreeArrayListExpand
            foreach(var node in treeArrayListExpand)//nowe elementy
            {
                string attr = node.attr;
                string iconStr = " ";
                if (attr.Contains("and"))
                {
                    iconStr = "AndIcon";
                }
                if (attr.Contains("or"))
                {
                    iconStr = "OrIcon";
                }
                treeStr += ",";
                string li_attr = "\"li_attr\":{\"class\":\"" + attr + "\"},\"icon\":\"" + iconStr + "\"" + ", \"state\" : {\"selected\" : false, \"opened\" : true, \"checked\" : true}";
                if (attr.Contains("up"))
                {
                    li_attr = "\"li_attr\":{\"class\":\"" + attr + "\"},\"icon\":\"" + iconStr + "\"" + ", \"state\" : {\"selected\" : false, \"opened\" : false, \"checked\" : true}";
                }
                treeStr += "{\"id\":\"" + node.id + "\",\"text\":\"" + node.text + "\",\"parent\":\""
                            + node.parent + "\"," + li_attr + "}";
                if (attr.Contains("up"))
                {
                    treeStr += ",";
                    string upName = node.text;
                    int pos = upName.IndexOf('[');
                    if (pos > 0)
                    {
                        upName = upName.Substring(0, pos - 1);
                    }
                    treeStr += dataPropertiesJSONFlat(upName, node.id);
                }
            }
            treeStr += "]";
            return treeStr;
        }

        public string dataPropertiesJSONFlat(string unode, string parentId)
        {
            DAFO_ONTOContext db = new DAFO_ONTOContext();
            List<string> dataPropList = (from s in db.MvMaxSuperClasses
                                         from d in db.Dom
                                         from r in db.Rng
                                         where s.Uname == unode && s.UnameMax == d.Uname
                                         && d.Bname == r.Bname && (r.Uname == "String" || r.Uname == "Integer")
                                         select d.Bname).ToList();
            string strJSON = "";
            int nodeId = 0;
            foreach (string s in dataPropList)
            {
                if (!s.Contains("Key"))
                {
                    
                    string attrId = parentId + "_" + nodeId++.ToString();
                    if (strJSON.Length > 1 && strJSON.Substring(strJSON.Length - 1, 1) == "}")
                    {
                        strJSON += ",";
                    }
                    nodeId++;
                    strJSON += "{\"id\":\"" + attrId +"\",\"text\": \"" + s + "\""+",\"parent\":\"" + parentId +"\",\"icon\":\" \", \"li_attr\": {\"class\": \"no dm incl\"}}";
                }
            }
            return strJSON;
        }
    }
}
