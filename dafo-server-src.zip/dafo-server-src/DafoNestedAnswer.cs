﻿using DafoApi.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DafoApi
{
    public class DafoNestedAnswer
    {
        public class NodeType
        {
            public string id;
            public string text;
            public string parent;
            public string attr;
        }
        public string CreateNestedAnswer(JArray treeJArray)
        {
            DafoQuery dq = new DafoQuery();
            DafoTree dt = new DafoTree();
            List<NodeType> nodeList = new List<NodeType>();// lista odpowiedzi pierwszego poziomu
            NodeType node = null;
            nodeList.Clear();
            for (int i = 0; i < treeJArray.Count(); i++)
            {
                node = treeJArray[i].ToObject<NodeType>();
                nodeList.Add(node);
            }
            string classId = nodeList[1].id;
            string className = nodeList[1].text;
            DafoTypes.answerType = dt.maxClass(className);
            string maxClassName = DafoTypes.answerType;
            DafoTypes.ExpNode rootExp = new DafoTypes.ExpNode();
            string sqlQuery = dq.CreateQueryExp(treeJArray, rootExp, "nestedanswer");
            //sqlQuery: zapytanie o obiekty zewnetrzne
            /*
            //uzyskac uporzadkowana liste rekordow NodeType (id,text) obiektow zewnetrznych
            string answerJStr = dsa.sqlAnswer(sqlQuery); // string JSON
            //zamienic na tablice JSON
            JObject answerJSON = JObject.Parse(answerJStr);
            JArray answerJArray = (JArray)answerJSON["answer"];
            List<NodeType>answerList = new List<NodeType>();// lista odpowiedzi pierwszego poziomu
            answerList.Clear();
            for (int i = 0; i < answerJArray.Count(); i++)
            {
                node = answerJArray[i].ToObject<NodeType>();
                node.parent = "#";
                answerList.Add(node);
            }
            */
            // okreslanie drugiego poziomu, parent to classId
            string bIdInv = "";
            for (int i = 0; i < nodeList.Count(); i++)
            {
                if (nodeList[i].parent == classId && 
                         (nodeList[i].attr.Contains("of") || nodeList[i].attr.Contains("om"))){// || nodeList[i].attr.Contains("dm"))){
                    bIdInv = nodeList[i].id;
                }

            }
            string uIdInv = "";
            string uNameInv = "";
            for (int i = 0; i < nodeList.Count(); i++)
            {
                if (nodeList[i].parent == bIdInv && nodeList[i].attr.Contains("up")){
                    uIdInv = nodeList[i].id;
                    uNameInv = nodeList[i].text;
                }
            }
            if (uIdInv == "")// gdy do inwersji wzieto tylko jeden poziom
            {
                uIdInv = nodeList[1].id;
                uNameInv = nodeList[1].text;
            }
            JArray treeJArrayInv0 = dq.InverseTreeArray(treeJArray, uIdInv);
            List<NodeType> nodeListInv = new List<NodeType>();// lista odpowiedzi pierwszego poziomu
            nodeList.Clear();
            for (int i = 0; i < treeJArrayInv0.Count(); i++)
            {
                node = treeJArrayInv0[i].ToObject<NodeType>();
                nodeListInv.Add(node);
            }
            // dodac dwa nowe elementy
            NodeType nodeId = new NodeType();
            nodeId.id = classId + "_1";
            nodeId.text = "_Id_" + maxClassName;
            nodeId.parent = classId;
            nodeId.attr = "no dm incl";
            nodeListInv.Add(nodeId);
            NodeType nodeVal = new NodeType();
            nodeVal.id = classId + "_2";
            //nodeVal.text = "@id@";
            nodeVal.text = "&id&";
            nodeVal.parent = nodeId.id;
            nodeVal.attr = "val const incl";
            nodeListInv.Add(nodeVal);
            // zamienic nodeListInv na JArray
            string Jstr = "{\"tree\":[";
            for (int i = 0; i < nodeListInv.Count(); i++)
            {
                if (Jstr.Length > 12)
                {
                    Jstr += ",";
                }
                Jstr += "{\"id\":\"" + nodeListInv[i].id + "\",\"text\":\"" + nodeListInv[i].text + "\",\"parent\":\"" 
                    + nodeListInv[i].parent+"\",\"attr\":\"" + nodeListInv[i].attr + "\"}";
            }
            Jstr += "]}";
            JObject treeJSONInv = JObject.Parse(Jstr);
            JArray treeJArrayInv = (JArray)treeJSONInv["tree"];
            DafoTypes.ExpNode rootExpInv = new DafoTypes.ExpNode();
            string sqlQueryInv = dq.CreateQueryExp(treeJArrayInv, rootExpInv, "nestedanswer");
            string nestedAnswer = PrepereNestedAnswer(sqlQuery, sqlQueryInv, uNameInv);
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
            Guid g = Guid.NewGuid();
            DafoTypes.token = g.ToString();
            ontoCtx.TransLog.Add(new TransLog() { Token = DafoTypes.token, Kind = "Nested", JsonStr = nestedAnswer, CreateTime = DateTime.Now });
            ontoCtx.SaveChanges();
            ontoCtx.Dispose();
            return DafoTypes.token; // nestedAnswer;
        }

        public string PrepereNestedAnswer(string sqlQuery, string sqlQueryPattern, string classNameInv)
        {
            int nodeId = 0;
            //uzyskac uporzadkowana liste rekordow NodeType (id,text) obiektow zewnetrznych
            DafoSqlAnswer dsa = new DafoSqlAnswer();
            DafoTree dt = new DafoTree();
            string answerJStr = dsa.sqlAnswer(sqlQuery); // string JSON
                                                         //zamienic na tablice JSON
            JObject answerJSON = JObject.Parse(answerJStr);
            JArray answerJArray = (JArray)answerJSON["answer"];
            List<NodeType> answerList = new List<NodeType>();// lista odpowiedzi pierwszego poziomu
            answerList.Clear();
            NodeType node = null;
            for (int i = 0; i < answerJArray.Count(); i++)
            {
                node = answerJArray[i].ToObject<NodeType>();
                node.attr = node.id;
                node.id = (nodeId++).ToString();
                node.parent = "#";
                node.text = (i+1).ToString() + ". " + node.text;
                answerList.Add(node);
            }
            List<NodeType> answerList1 = new List<NodeType>();// lista odpowiedzi pierwszego poziomu
            answerList1.Clear();
            for (int i=0; i< answerList.Count(); i++)
            {
                //string sqlQueryNested = sqlQueryPattern.Replace("'@id@'", answerList[i].attr);
                string sqlQueryNested = sqlQueryPattern.Replace("'&id&'", answerList[i].attr);
                DafoTypes.answerType = dt.maxClass(classNameInv);
                string answerJStr1 = dsa.sqlAnswer(sqlQueryNested);
                JObject answerJSON1 = JObject.Parse(answerJStr1);
                JArray answerJArray1 = (JArray)answerJSON1["answer"];
                for (int k = 0; k < answerJArray1.Count(); k++)
                {
                    node = answerJArray1[k].ToObject<NodeType>();
                    node.attr = node.id;
                    node.id = (nodeId++).ToString();
                    node.parent = answerList[i].id;
                    node.text = (k+1).ToString() + ". " + node.text;
                    answerList1.Add(node);
                }
            }
            string ansJSON = @"[";
            for (int i = 0; i < answerList.Count(); i++)
            {
                if (ansJSON.Length > 15)
                {
                    ansJSON += ",";
                }
                ansJSON += EditJElement(answerList[i].id, answerList[i].text, answerList[i].parent); //, answerList[i].attr);
            }
            for (int i = 0; i < answerList1.Count(); i++)
            {
                if (ansJSON.Length > 15)
                {
                    ansJSON += ",";
                }
                ansJSON += EditJElement(answerList1[i].id, answerList1[i].text, answerList1[i].parent);//, answerList1[i].attr);
            }
            ansJSON += "]";
            return ansJSON;
        }

        public string EditJElement(string id, string text, string parent) //, string attr)
        {
            return "{\"id\":\"" + id + "\",\"text\":\"" +text+ "\",\"parent\":\"" + parent +"\"}"; // "\",\"attr\":\"" + attr + "\"}";
        }
        public string xEditJElement(string id, string text, string parent)//, string attr)
        {
            return "{\"id\":\"" + id + "\",\"text\":\"" + text + "\",\"parent\":\"" + parent + "\",\"state\":{ \"opened\" : false}}";
        }
        public string yEditJElementState(string id, string text, string parent)//, string attr)
        {
            return "{\"id\":\"" + id + "\",\"text\":\"" + text + "\",\"parent\":\"" + parent + "\", \"state\" : {\"selected\" : false, \"opened\" : false, \"checked\" : false}}";
        }
    }
}
