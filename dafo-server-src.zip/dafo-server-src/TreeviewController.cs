﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using DafoApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Collections;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DafoApi
{
    [Route("api/treeview")]
    [EnableCors("AllowAll")]

    public class TreeviewController : Controller
    {
        DAFO_AUXContext db = new DAFO_AUXContext();
        DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
        // GET: api/<controller>
        [HttpGet]
        //public IEnumerable<TreeViewTab> Get()
        public string Get()
        {
            var queryString = HttpContext.Request.Query;
            StringValues parVal1, parVal2;
            queryString.TryGetValue("type", out parVal1);
            queryString.TryGetValue("property", out parVal2);
            var parVal1str = (string)parVal1;
            var parVal2str = (string)parVal2;
            DafoTree dt = new DafoTree();

            if (parVal1str == "classes")// udostepnienie wszystkich klas i ich podklas
            {
                return dt.getClassHierarchyList();
            }
            if (parVal1str == "tree")// dla podanych ciagow wyznacza drzewo interfejsu fasetowego w postaci JSON
            {
                string str = dt.strToJSON(parVal2str);
                return str;
            }
            if (parVal1str == "before")// żąda efektu prepisywania zapytan fasetowego do FO before
            {
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var before = (from p in ontoCtx.TransLog
                                 where p.Token == parVal2str && p.Kind == "Before"
                                 select p).FirstOrDefault();
                before.LastAccess = DateTime.Now;
                ontoCtx.SaveChanges();
                ontoCtx.Dispose();
                return before.JsonStr;
            }
            if (parVal1str == "after")// żąda efektu prepisywania zapytan fasetowego do FO before
            {
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var after = (from p in ontoCtx.TransLog
                                where p.Token == parVal2str && p.Kind == "After"
                                select p).FirstOrDefault();
                after.LastAccess = DateTime.Now;
                ontoCtx.SaveChanges();
                ontoCtx.Dispose();
                return after.JsonStr;
            }
            if (parVal1str == "sqlquery")// żąda efektu prepisywania zapytan fasetowego do FO before
            {
                Guid token = new Guid(parVal2str);
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var sqlquery = (from p in ontoCtx.TransLog
                                   where p.Token == parVal2str && p.Kind == "SQLQuery"
                                   select p).FirstOrDefault();
                sqlquery.LastAccess = DateTime.Now;
                ontoCtx.SaveChanges();
                ontoCtx.Dispose();
                return sqlquery.JsonStr;
            }
            if (parVal1str == "nested")// żąda efektu prepisywania zapytan fasetowego do FO before
            {
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var nested = (from p in ontoCtx.TransLog
                              where p.Token == parVal2str && p.Kind == "Nested"
                              select p).FirstOrDefault();
                nested.LastAccess = DateTime.Now;
                ontoCtx.SaveChanges();
                ontoCtx.Dispose();
                return nested.JsonStr;
            }
            return "";
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public TreeViewTab Get(int id)
        {
            TreeViewTab tv = db.TreeViewTab.Find(id);
            return tv;
        }

        // POST api/<controller>
        [HttpPost]
        public string Post([FromBody] string dafoString)
        {
            DafoTypes.ExpNode rootExp = new DafoTypes.ExpNode();
            JObject dafoJSON = JObject.Parse(dafoString);
            string param1 = (string)dafoJSON["dafo"]["par1"];
            string attrName = (string)dafoJSON["dafo"]["par2"];
            JArray treeArray = (JArray)dafoJSON["dafo"]["tree"];
            DafoQuery dq = new DafoQuery();
            DafoSqlAnswer dsa = new DafoSqlAnswer();
            string ansJSON;
            
            if (param1 == "values")
            { // values
                string classId = (string)dafoJSON["dafo"]["par3"];
                JArray treeArrayInv = dq.InverseTreeArray(treeArray,classId);
                string sqlQuery = dq.CreateQueryExp(treeArrayInv, rootExp,"values");
                ansJSON = dsa.valuesToJSON(attrName, sqlQuery);
                return ansJSON;
            } else
            if (param1 == "focuson")
            { // focuson
                string classId = (string)dafoJSON["dafo"]["par3"];
                string className = (string)dafoJSON["dafo"]["par2"];
                JArray treeArrayInv = dq.InverseTreeArray(treeArray, classId);
                string treeStr = dq.TreeArrayToStr(treeArrayInv);
                return treeStr;
            } else
            if (param1 == "explore")
            { // focuson
                string classId = (string)dafoJSON["dafo"]["par3"];
                string className = (string)dafoJSON["dafo"]["par2"];
                //JArray treeArrayExt = dq.ExtendTreeArray(treeArray, classId, className);
                string treeStrExt = dq.ExtendTreeArray(treeArray, classId, className);
                return treeStrExt;
            } else
            if (param1 == "nestedanswer")
            { // nested answer
                //string sqlQuery = dq.CreateQueryExp(treeArray, rootExp, "answer");
                //ansJSON = DafoTypes.token + dsa.sqlAnswer(sqlQuery);
                DafoNestedAnswer dna = new DafoNestedAnswer();
                string token  = dna.CreateNestedAnswer(treeArray);
                return token;
            }
            else // query
            if (param1 == "query")
            {
                string sqlQuery = dq.CreateQueryExp(treeArray, rootExp,"answer");
                ansJSON = DafoTypes.token + dsa.sqlAnswer(sqlQuery);
                return ansJSON;
            }
            return "**ERROR**";
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]TreeViewTab tv)
        { 
            var tv1 = db.TreeViewTab.Find(id);
            tv1.TreeViewRep = tv.TreeViewRep;
            db.SaveChanges();
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            TreeViewTab tv = db.TreeViewTab.Find(id);
            db.TreeViewTab.Remove(tv);
            db.SaveChanges();
        }
    }
}
