﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Sigma
    {
        public Sigma()
        {
            DomPathRngUnameDomNavigation = new HashSet<DomPathRng>();
            DomPathRngUnameRngNavigation = new HashSet<DomPathRng>();
            DomPredRngUnameDomNavigation = new HashSet<DomPredRng>();
            DomPredRngUnameRngNavigation = new HashSet<DomPredRng>();
            DomUnameNavigation = new HashSet<Dom>();
            FunkcUname1Navigation = new HashSet<Funkc>();
            FunkcUname2Navigation = new HashSet<Funkc>();
            InvBname1Navigation = new HashSet<Inv>();
            InvBname2Navigation = new HashSet<Inv>();
            KeyUname1Navigation = new HashSet<Key>();
            KeyUname2Navigation = new HashSet<Key>();
            RngUnameNavigation = new HashSet<Rng>();
            Spec1BnameNavigation = new HashSet<Spec1>();
            Spec1UnameNavigation = new HashSet<Spec1>();
            Spec2BnameNavigation = new HashSet<Spec2>();
            Spec2Uname1Navigation = new HashSet<Spec2>();
            Spec2Uname2Navigation = new HashSet<Spec2>();
            SubMaxUnameMaxNavigation = new HashSet<SubMax>();
            SubMaxUnameNavigation = new HashSet<SubMax>();
            SubUname2Navigation = new HashSet<Sub>();
        }

        public string Name { get; set; }
        public string Type { get; set; }
        public string Kind { get; set; }
        public string LabNull { get; set; }
        public string TabMap { get; set; }
        public string AttMap { get; set; }
        public string DomMap { get; set; }
        public string RngMap { get; set; }
        public string FuncType { get; set; }

        public virtual Dom DomBnameNavigation { get; set; }
        public virtual DomPredRng DomPredRngBnameNavigation { get; set; }
        public virtual Funkc FunkcBnameNavigation { get; set; }
        public virtual Key KeyBnameNavigation { get; set; }
        public virtual Rng RngBnameNavigation { get; set; }
        public virtual Sub SubUname1Navigation { get; set; }
        public virtual ICollection<DomPathRng> DomPathRngUnameDomNavigation { get; set; }
        public virtual ICollection<DomPathRng> DomPathRngUnameRngNavigation { get; set; }
        public virtual ICollection<DomPredRng> DomPredRngUnameDomNavigation { get; set; }
        public virtual ICollection<DomPredRng> DomPredRngUnameRngNavigation { get; set; }
        public virtual ICollection<Dom> DomUnameNavigation { get; set; }
        public virtual ICollection<Funkc> FunkcUname1Navigation { get; set; }
        public virtual ICollection<Funkc> FunkcUname2Navigation { get; set; }
        public virtual ICollection<Inv> InvBname1Navigation { get; set; }
        public virtual ICollection<Inv> InvBname2Navigation { get; set; }
        public virtual ICollection<Key> KeyUname1Navigation { get; set; }
        public virtual ICollection<Key> KeyUname2Navigation { get; set; }
        public virtual ICollection<Rng> RngUnameNavigation { get; set; }
        public virtual ICollection<Spec1> Spec1BnameNavigation { get; set; }
        public virtual ICollection<Spec1> Spec1UnameNavigation { get; set; }
        public virtual ICollection<Spec2> Spec2BnameNavigation { get; set; }
        public virtual ICollection<Spec2> Spec2Uname1Navigation { get; set; }
        public virtual ICollection<Spec2> Spec2Uname2Navigation { get; set; }
        public virtual ICollection<SubMax> SubMaxUnameMaxNavigation { get; set; }
        public virtual ICollection<SubMax> SubMaxUnameNavigation { get; set; }
        public virtual ICollection<Sub> SubUname2Navigation { get; set; }
    }
}
