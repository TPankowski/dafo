﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class TreeViewTab
    {
        public int Id { get; set; }
        public string TreeViewRep { get; set; }
        public string Src { get; set; }
    }
}
