﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class MvValues
    {
        public string Values { get; set; }
    }
}
