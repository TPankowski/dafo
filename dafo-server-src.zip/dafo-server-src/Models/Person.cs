﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Person
    {
        public Person()
        {
            AffiliationNavigation = new HashSet<Affiliation>();
            AuthorPaper = new HashSet<AuthorPaper>();
            EditorProc = new HashSet<EditorProc>();
        }

        public int Id { get; set; }
        public string DblpKey { get; set; }
        public string DblpXml { get; set; }
        public string Name { get; set; }
        public string N { get; set; }
        public string HtmlFile { get; set; }
        public string PersonUrl { get; set; }
        public string Affiliation { get; set; }
        public string Affiliation1 { get; set; }
        public string Affiliation2 { get; set; }
        public string Affiliation3 { get; set; }
        public string Html { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public virtual ICollection<Affiliation> AffiliationNavigation { get; set; }
        public virtual ICollection<AuthorPaper> AuthorPaper { get; set; }
        public virtual ICollection<EditorProc> EditorProc { get; set; }
    }
}
