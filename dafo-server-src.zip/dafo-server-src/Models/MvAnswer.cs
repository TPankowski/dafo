﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class MvAnswer
    {
        public int Id { get; set; }
        public string Html { get; set; }
    }
}
