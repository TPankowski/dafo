﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Paper
    {
        public Paper()
        {
            AuthorPaper = new HashSet<AuthorPaper>();
        }

        public int Id { get; set; }
        public string DblpKey { get; set; }
        public string Title { get; set; }
        public string Pages { get; set; }
        public string EeDoi { get; set; }
        public string PaperUrl { get; set; }
        public int? ProcId { get; set; }
        public string Authors { get; set; }
        public string Html { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }

        public virtual Proceedings Proc { get; set; }
        public virtual ICollection<AuthorPaper> AuthorPaper { get; set; }
    }
}
