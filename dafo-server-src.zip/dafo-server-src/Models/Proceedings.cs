﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Proceedings
    {
        public Proceedings()
        {
            EditorProc = new HashSet<EditorProc>();
            Paper = new HashSet<Paper>();
        }

        public int Id { get; set; }
        public string DblpKey { get; set; }
        public string DblpHtml { get; set; }
        public string Year { get; set; }
        public string BookTitleShort { get; set; }
        public string BookTitle { get; set; }
        public string Series { get; set; }
        public string Volume { get; set; }
        public string Publisher { get; set; }
        public string Isbn { get; set; }
        public string Editor { get; set; }
        public int? ConfId { get; set; }
        public string Html { get; set; }

        public virtual Conference Conf { get; set; }
        public virtual ICollection<EditorProc> EditorProc { get; set; }
        public virtual ICollection<Paper> Paper { get; set; }
    }
}
