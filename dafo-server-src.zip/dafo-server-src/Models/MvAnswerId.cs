﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class MvAnswerId
    {
        public int Id { get; set; }
    }
}
