﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class TransLog
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public string Kind { get; set; }
        public string JsonStr { get; set; }
        public DateTime? CreateTime { get; set; }
        public DateTime? LastAccess { get; set; }
    }
}
