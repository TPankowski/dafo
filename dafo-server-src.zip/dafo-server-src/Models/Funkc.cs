﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Funkc
    {
        public string Uname1 { get; set; }
        public string Bname { get; set; }
        public string Uname2 { get; set; }

        public virtual Sigma BnameNavigation { get; set; }
        public virtual Sigma Uname1Navigation { get; set; }
        public virtual Sigma Uname2Navigation { get; set; }
    }
}
