﻿using System;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Newtonsoft.Json.Linq;

namespace DafoApi.Models
{
    public partial class DAFO_02Context : DbContext
    {
        public DAFO_02Context()
        {
        }

        public DAFO_02Context(DbContextOptions<DAFO_02Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Affiliation> Affiliation { get; set; }
        public virtual DbSet<AuthorPaper> AuthorPaper { get; set; }
        public virtual DbSet<Conference> Conference { get; set; }
        public virtual DbSet<EditorProc> EditorProc { get; set; }
        public virtual DbSet<MvAnswer> MvAnswer { get; set; }
        public virtual DbSet<MvAnswerId> MvAnswerId { get; set; }
        public virtual DbSet<MvValues> MvValues { get; set; }
        public virtual DbSet<Paper> Paper { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<Proceedings> Proceedings { get; set; }

        // Unable to generate entity type for table 'dbo.Triple'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.Conference_Arch'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                using (StreamReader r = new StreamReader("appsettings.json"))
                {
                    string jsonStr = r.ReadToEnd();
                    JObject treeJSON = JObject.Parse(jsonStr);
                    string DAFO_DBContextStr = treeJSON["ConnectionStrings"]["DAFO_DBContext"].ToString();
                    optionsBuilder.UseSqlServer(DAFO_DBContextStr);
                }
                //optionsBuilder.UseSqlServer("Server=SATURN\\SQL2017;Database=DAFO_02;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Affiliation>(entity =>
            {
                entity.Property(e => e.Affiliation1)
                    .HasColumnName("Affiliation")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.HasOne(d => d.Person)
                    .WithMany(p => p.AffiliationNavigation)
                    .HasForeignKey(d => d.PersonId)
                    .HasConstraintName("FK__Affiliati__Perso__1F63A897");
            });

            modelBuilder.Entity<AuthorPaper>(entity =>
            {
                entity.HasKey(e => new { e.PersonId, e.PaperId })
                    .HasName("PK__AuthorPa__00979AC525B46BFC");

                entity.HasOne(d => d.Paper)
                    .WithMany(p => p.AuthorPaper)
                    .HasForeignKey(d => d.PaperId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__AuthorPap__Paper__37703C52");

                entity.HasOne(d => d.Person)
                    .WithMany(p => p.AuthorPaper)
                    .HasForeignKey(d => d.PersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__AuthorPap__Perso__367C1819");
            });

            modelBuilder.Entity<Conference>(entity =>
            {
                entity.HasIndex(e => e.DblpKey)
                    .HasName("UQ__Conferen__B6B4B034E715CB0D")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Acronym)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ConfHomeUrl)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DblpKey)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EditionNo)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.FullName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Html)
                    .HasColumnName("HTML")
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.Organizer)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ShortName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Year)
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<EditorProc>(entity =>
            {
                entity.HasKey(e => new { e.PersonId, e.ProcId })
                    .HasName("PK__EditorPr__5A53DA286271E0E6");

                entity.HasOne(d => d.Person)
                    .WithMany(p => p.EditorProc)
                    .HasForeignKey(d => d.PersonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__EditorPro__Perso__3A4CA8FD");

                entity.HasOne(d => d.Proc)
                    .WithMany(p => p.EditorProc)
                    .HasForeignKey(d => d.ProcId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__EditorPro__ProcI__3B40CD36");
            });

            modelBuilder.Entity<MvAnswer>(entity =>
            {
                entity.ToTable("mv_Answer");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Html)
                    .HasColumnName("HTML")
                    .HasMaxLength(4000)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MvAnswerId>(entity =>
            {
                entity.ToTable("mv_AnswerId");

                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<MvValues>(entity =>
            {
                entity.HasKey(e => e.Values)
                    .HasName("PK__mv_Value__CCD24C60705EBFEF");

                entity.ToTable("mv_Values");

                entity.Property(e => e.Values)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .ValueGeneratedNever();
            });

            modelBuilder.Entity<Paper>(entity =>
            {
                entity.HasIndex(e => e.DblpKey)
                    .HasName("UQ__Paper__B6B4B0347CBA1EEA")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Authors)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.DblpKey)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.EeDoi)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Html)
                    .HasColumnName("HTML")
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Pages)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PaperUrl)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.HasOne(d => d.Proc)
                    .WithMany(p => p.Paper)
                    .HasForeignKey(d => d.ProcId)
                    .HasConstraintName("FK__Paper__ProcId__339FAB6E");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasIndex(e => e.DblpKey)
                    .HasName("UQ__Person__B6B4B03465127911")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Affiliation)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Affiliation1)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Affiliation2)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Affiliation3)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.DblpKey)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.DblpXml)
                    .HasColumnName("DblpXML")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Html)
                    .HasColumnName("HTML")
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.HtmlFile)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.N)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.PersonUrl)
                    .HasMaxLength(80)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Proceedings>(entity =>
            {
                entity.HasIndex(e => e.DblpKey)
                    .HasName("UQ__Proceedi__B6B4B0345A4EF982")
                    .IsUnique();

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.BookTitle)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.BookTitleShort)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.DblpHtml)
                    .HasColumnName("DblpHTML")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.DblpKey)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Editor)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Html)
                    .HasColumnName("HTML")
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.Isbn)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Publisher)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Series)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Volume)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Year)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.HasOne(d => d.Conf)
                    .WithMany(p => p.Proceedings)
                    .HasForeignKey(d => d.ConfId)
                    .HasConstraintName("FK__Proceedin__ConfI__2FCF1A8A");
            });
        }
    }
}
