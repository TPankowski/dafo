﻿using System;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using Microsoft.EntityFrameworkCore.Metadata;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class DAFO_ONTOContext : DbContext
    {
        public DAFO_ONTOContext()
        {
        }

        public DAFO_ONTOContext(DbContextOptions<DAFO_ONTOContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Chain> Chain { get; set; }
        public virtual DbSet<Dom> Dom { get; set; }
        public virtual DbSet<DomPathRng> DomPathRng { get; set; }
        public virtual DbSet<DomPredRng> DomPredRng { get; set; }
        public virtual DbSet<Funkc> Funkc { get; set; }
        public virtual DbSet<Inv> Inv { get; set; }
        public virtual DbSet<Key> Key { get; set; }
        public virtual DbSet<MvMaxSuperClasses> MvMaxSuperClasses { get; set; }
        public virtual DbSet<MvSubTypeAll> MvSubTypeAll { get; set; }
        public virtual DbSet<Query> Query { get; set; }
        public virtual DbSet<Rng> Rng { get; set; }
        public virtual DbSet<Sigma> Sigma { get; set; }
        public virtual DbSet<Spec1> Spec1 { get; set; }
        public virtual DbSet<Spec2> Spec2 { get; set; }
        public virtual DbSet<Sub> Sub { get; set; }
        public virtual DbSet<SubMax> SubMax { get; set; }
        public virtual DbSet<SubProp> SubProp { get; set; }
        public virtual DbSet<TotalDom> TotalDom { get; set; }
        public virtual DbSet<TransLog> TransLog { get; set; }
        public virtual DbSet<TreeViewPath> TreeViewPath { get; set; }
        public virtual DbSet<TreeViewTabOnto> TreeViewTabOnto { get; set; }
        public virtual DbSet<Triple> Triple { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                using (StreamReader r = new StreamReader("appsettings.json"))
                {
                    string jsonStr = r.ReadToEnd();
                    JObject treeJSON = JObject.Parse(jsonStr);
                    string DAFO_ONTOContextStr = treeJSON["ConnectionStrings"]["DAFO_ONTOContext"].ToString();
                    optionsBuilder.UseSqlServer(DAFO_ONTOContextStr);
                }
                //optionsBuilder.UseSqlServer("Server=SATURN\\SQL2017;Database=DAFO_ONTO;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Chain>(entity =>
            {
                entity.Property(e => e.Bname1)
                    .HasColumnName("BName1")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Bname2)
                    .HasColumnName("BName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Bname3)
                    .HasColumnName("BName3")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Dom>(entity =>
            {
                entity.HasKey(e => e.Bname)
                    .HasName("PK__Dom__3FF35083C3B73E2C");

                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DbConstr)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithOne(p => p.DomBnameNavigation)
                    .HasForeignKey<Dom>(d => d.Bname)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Dom__BName__19DFD96B");

                entity.HasOne(d => d.UnameNavigation)
                    .WithMany(p => p.DomUnameNavigation)
                    .HasForeignKey(d => d.Uname)
                    .HasConstraintName("FK__Dom__UName__1AD3FDA4");
            });

            modelBuilder.Entity<DomPathRng>(entity =>
            {
                entity.Property(e => e.Path)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.UnameDom)
                    .HasColumnName("UNameDom")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UnameRng)
                    .HasColumnName("UNameRng")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.UnameDomNavigation)
                    .WithMany(p => p.DomPathRngUnameDomNavigation)
                    .HasForeignKey(d => d.UnameDom)
                    .HasConstraintName("FK__DomPathRn__UName__59904A2C");

                entity.HasOne(d => d.UnameRngNavigation)
                    .WithMany(p => p.DomPathRngUnameRngNavigation)
                    .HasForeignKey(d => d.UnameRng)
                    .HasConstraintName("FK__DomPathRn__UName__5A846E65");
            });

            modelBuilder.Entity<DomPredRng>(entity =>
            {
                entity.HasKey(e => e.Bname)
                    .HasName("PK__DomPredR__3FF35083E7CA9548");

                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.UnameDom)
                    .HasColumnName("UNameDom")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UnameRng)
                    .HasColumnName("UNameRng")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithOne(p => p.DomPredRngBnameNavigation)
                    .HasForeignKey<DomPredRng>(d => d.Bname)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__DomPredRn__BName__2F9A1060");

                entity.HasOne(d => d.UnameDomNavigation)
                    .WithMany(p => p.DomPredRngUnameDomNavigation)
                    .HasForeignKey(d => d.UnameDom)
                    .HasConstraintName("FK__DomPredRn__UName__2EA5EC27");

                entity.HasOne(d => d.UnameRngNavigation)
                    .WithMany(p => p.DomPredRngUnameRngNavigation)
                    .HasForeignKey(d => d.UnameRng)
                    .HasConstraintName("FK__DomPredRn__UName__308E3499");
            });

            modelBuilder.Entity<Funkc>(entity =>
            {
                entity.HasKey(e => e.Bname)
                    .HasName("PK__Funkc__3FF350838381F1F1");

                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Uname1)
                    .HasColumnName("UName1")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Uname2)
                    .HasColumnName("UName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithOne(p => p.FunkcBnameNavigation)
                    .HasForeignKey<Funkc>(d => d.Bname)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Funkc__BName__3D2915A8");

                entity.HasOne(d => d.Uname1Navigation)
                    .WithMany(p => p.FunkcUname1Navigation)
                    .HasForeignKey(d => d.Uname1)
                    .HasConstraintName("FK__Funkc__UName1__3C34F16F");

                entity.HasOne(d => d.Uname2Navigation)
                    .WithMany(p => p.FunkcUname2Navigation)
                    .HasForeignKey(d => d.Uname2)
                    .HasConstraintName("FK__Funkc__UName2__3E1D39E1");
            });

            modelBuilder.Entity<Inv>(entity =>
            {
                entity.Property(e => e.Bname1)
                    .HasColumnName("BName1")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Bname2)
                    .HasColumnName("BName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Bname1Navigation)
                    .WithMany(p => p.InvBname1Navigation)
                    .HasForeignKey(d => d.Bname1)
                    .HasConstraintName("FK__Inv__BName1__3864608B");

                entity.HasOne(d => d.Bname2Navigation)
                    .WithMany(p => p.InvBname2Navigation)
                    .HasForeignKey(d => d.Bname2)
                    .HasConstraintName("FK__Inv__BName2__395884C4");
            });

            modelBuilder.Entity<Key>(entity =>
            {
                entity.HasKey(e => e.Bname)
                    .HasName("PK__Key__3FF35083D5744E4C");

                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Uname1)
                    .HasColumnName("UName1")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Uname2)
                    .HasColumnName("UName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithOne(p => p.KeyBnameNavigation)
                    .HasForeignKey<Key>(d => d.Bname)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Key__BName__1D7B6025");

                entity.HasOne(d => d.Uname1Navigation)
                    .WithMany(p => p.KeyUname1Navigation)
                    .HasForeignKey(d => d.Uname1)
                    .HasConstraintName("FK__Key__UName1__1C873BEC");

                entity.HasOne(d => d.Uname2Navigation)
                    .WithMany(p => p.KeyUname2Navigation)
                    .HasForeignKey(d => d.Uname2)
                    .HasConstraintName("FK__Key__UName2__1E6F845E");
            });

            modelBuilder.Entity<MvMaxSuperClasses>(entity =>
            {
                entity.ToTable("mv_MaxSuperClasses");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UnameMax)
                    .HasColumnName("UNameMax")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MvSubTypeAll>(entity =>
            {
                entity.ToTable("mv_SubTypeAll");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Kind)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaxType)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Parent)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Query>(entity =>
            {
                entity.Property(e => e.Path)
                    .HasMaxLength(1000)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Rng>(entity =>
            {
                entity.HasKey(e => e.Bname)
                    .HasName("PK__Rng__3FF350832D13D7A1");

                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DbConstr)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithOne(p => p.RngBnameNavigation)
                    .HasForeignKey<Rng>(d => d.Bname)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Rng__BName__1DB06A4F");

                entity.HasOne(d => d.UnameNavigation)
                    .WithMany(p => p.RngUnameNavigation)
                    .HasForeignKey(d => d.Uname)
                    .HasConstraintName("FK__Rng__UName__1EA48E88");
            });

            modelBuilder.Entity<Sigma>(entity =>
            {
                entity.HasKey(e => e.Name)
                    .HasName("PK__Sigma__737584F705D98498");

                entity.Property(e => e.Name)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.AttMap)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DomMap)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.FuncType)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Kind)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.LabNull)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.RngMap)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TabMap)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Spec1>(entity =>
            {
                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Const)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithMany(p => p.Spec1BnameNavigation)
                    .HasForeignKey(d => d.Bname)
                    .HasConstraintName("FK__Spec1__BName__0880433F");

                entity.HasOne(d => d.UnameNavigation)
                    .WithMany(p => p.Spec1UnameNavigation)
                    .HasForeignKey(d => d.Uname)
                    .HasConstraintName("FK__Spec1__UName__09746778");
            });

            modelBuilder.Entity<Spec2>(entity =>
            {
                entity.Property(e => e.Bname)
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Uname1)
                    .HasColumnName("UName1")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Uname2)
                    .HasColumnName("UName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BnameNavigation)
                    .WithMany(p => p.Spec2BnameNavigation)
                    .HasForeignKey(d => d.Bname)
                    .HasConstraintName("FK__Spec2__BName__25518C17");

                entity.HasOne(d => d.Uname1Navigation)
                    .WithMany(p => p.Spec2Uname1Navigation)
                    .HasForeignKey(d => d.Uname1)
                    .HasConstraintName("FK__Spec2__UName1__2645B050");

                entity.HasOne(d => d.Uname2Navigation)
                    .WithMany(p => p.Spec2Uname2Navigation)
                    .HasForeignKey(d => d.Uname2)
                    .HasConstraintName("FK__Spec2__UName2__2739D489");
            });

            modelBuilder.Entity<Sub>(entity =>
            {
                entity.HasKey(e => e.Uname1)
                    .HasName("PK__Sub__49DA7FE324221B1D");

                entity.Property(e => e.Uname1)
                    .HasColumnName("UName1")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.Uname2)
                    .HasColumnName("UName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Uname1Navigation)
                    .WithOne(p => p.SubUname1Navigation)
                    .HasForeignKey<Sub>(d => d.Uname1)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Sub__UName1__160F4887");

                entity.HasOne(d => d.Uname2Navigation)
                    .WithMany(p => p.SubUname2Navigation)
                    .HasForeignKey(d => d.Uname2)
                    .HasConstraintName("FK__Sub__UName2__17036CC0");
            });

            modelBuilder.Entity<SubMax>(entity =>
            {
                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UnameMax)
                    .HasColumnName("UNameMax")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.UnameNavigation)
                    .WithMany(p => p.SubMaxUnameNavigation)
                    .HasForeignKey(d => d.Uname)
                    .HasConstraintName("FK__SubMax__UName__00AA174D");

                entity.HasOne(d => d.UnameMaxNavigation)
                    .WithMany(p => p.SubMaxUnameMaxNavigation)
                    .HasForeignKey(d => d.UnameMax)
                    .HasConstraintName("FK__SubMax__UNameMax__019E3B86");
            });

            modelBuilder.Entity<SubProp>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Bname1)
                    .IsRequired()
                    .HasColumnName("BName1")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Bname2)
                    .HasColumnName("BName2")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TotalDom>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Bname)
                    .IsRequired()
                    .HasColumnName("BName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DbConstr)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .HasColumnName("UName")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TransLog>(entity =>
            {
                entity.Property(e => e.CreateTime).HasColumnType("datetime");

                entity.Property(e => e.JsonStr)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.Kind)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastAccess).HasColumnType("datetime");

                entity.Property(e => e.Token)
                    .IsRequired()
                    .HasMaxLength(36)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TreeViewPath>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Path)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.PathMax)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.Semantics)
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TreeViewTabOnto>(entity =>
            {
                entity.ToTable("TreeViewTab-Onto");

                entity.Property(e => e.Checked)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.FuncType)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Parent)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Tvid).HasColumnName("TVId");

                entity.HasOne(d => d.Tv)
                    .WithMany(p => p.TreeViewTabOnto)
                    .HasForeignKey(d => d.Tvid)
                    .HasConstraintName("FK__TreeViewTa__TVId__7CD98669");
            });

            modelBuilder.Entity<Triple>(entity =>
            {
                entity.Property(e => e.Bp)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Ob)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Su)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });
        }
    }
}
