﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class MvMaxSuperClasses
    {
        public int Id { get; set; }
        public string Uname { get; set; }
        public string UnameMax { get; set; }
        public int? Level { get; set; }
    }
}
