﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class EditorProc
    {
        public int PersonId { get; set; }
        public int ProcId { get; set; }

        public virtual Person Person { get; set; }
        public virtual Proceedings Proc { get; set; }
    }
}
