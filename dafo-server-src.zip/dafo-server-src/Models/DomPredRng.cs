﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class DomPredRng
    {
        public string UnameDom { get; set; }
        public string Bname { get; set; }
        public string UnameRng { get; set; }

        public virtual Sigma BnameNavigation { get; set; }
        public virtual Sigma UnameDomNavigation { get; set; }
        public virtual Sigma UnameRngNavigation { get; set; }
    }
}
