﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Rng
    {
        public string Bname { get; set; }
        public string Uname { get; set; }
        public string DbConstr { get; set; }

        public virtual Sigma BnameNavigation { get; set; }
        public virtual Sigma UnameNavigation { get; set; }
    }
}
