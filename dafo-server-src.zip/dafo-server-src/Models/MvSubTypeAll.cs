﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class MvSubTypeAll
    {
        public int Id { get; set; }
        public string Uname { get; set; }
        public int? Level { get; set; }
        public string Kind { get; set; }
        public string Parent { get; set; }
        public string MaxType { get; set; }
    }
}
