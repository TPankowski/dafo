﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Affiliation
    {
        public int Id { get; set; }
        public int? PersonId { get; set; }
        public string Affiliation1 { get; set; }
        public int? AffilPos { get; set; }

        public virtual Person Person { get; set; }
    }
}
