﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class TotalDom
    {
        public string Bname { get; set; }
        public string Uname { get; set; }
        public string DbConstr { get; set; }
        public int Id { get; set; }
    }
}
