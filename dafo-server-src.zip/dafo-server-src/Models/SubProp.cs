﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class SubProp
    {
        public string Bname1 { get; set; }
        public string Bname2 { get; set; }
        public int Id { get; set; }
    }
}
