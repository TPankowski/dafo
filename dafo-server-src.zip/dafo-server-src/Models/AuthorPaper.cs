﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class AuthorPaper
    {
        public int PersonId { get; set; }
        public int PaperId { get; set; }

        public virtual Paper Paper { get; set; }
        public virtual Person Person { get; set; }
    }
}
