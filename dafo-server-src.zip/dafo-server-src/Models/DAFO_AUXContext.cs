﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DafoApi.Models
{
    public partial class DAFO_AUXContext : DbContext
    {
        public DAFO_AUXContext()
        {
        }

        public DAFO_AUXContext(DbContextOptions<DAFO_AUXContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TreeViewTab> TreeViewTab { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=SATURN\\SQL2017;Database=DAFO_AUX;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<TreeViewTab>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Src)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.TreeViewRep).IsUnicode(false);
            });
        }
    }
}
