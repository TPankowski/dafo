﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Inv
    {
        public int Id { get; set; }
        public string Bname1 { get; set; }
        public string Bname2 { get; set; }

        public virtual Sigma Bname1Navigation { get; set; }
        public virtual Sigma Bname2Navigation { get; set; }
    }
}
