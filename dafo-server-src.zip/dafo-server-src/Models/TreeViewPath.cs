﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class TreeViewPath
    {
        public TreeViewPath()
        {
            TreeViewTabOnto = new HashSet<TreeViewTabOnto>();
        }

        public int Id { get; set; }
        public string Path { get; set; }
        public string PathMax { get; set; }
        public string Semantics { get; set; }

        public virtual ICollection<TreeViewTabOnto> TreeViewTabOnto { get; set; }
    }
}
