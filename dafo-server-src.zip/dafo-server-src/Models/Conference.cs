﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Conference
    {
        public Conference()
        {
            Proceedings = new HashSet<Proceedings>();
        }

        public int Id { get; set; }
        public string DblpKey { get; set; }
        public string ShortName { get; set; }
        public string Acronym { get; set; }
        public string EditionNo { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string Year { get; set; }
        public string FullName { get; set; }
        public string Organizer { get; set; }
        public string ConfHomeUrl { get; set; }
        public string Html { get; set; }

        public virtual ICollection<Proceedings> Proceedings { get; set; }
    }
}
