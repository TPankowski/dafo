﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class DomPathRng
    {
        public int Id { get; set; }
        public string UnameDom { get; set; }
        public string Path { get; set; }
        public string UnameRng { get; set; }

        public virtual Sigma UnameDomNavigation { get; set; }
        public virtual Sigma UnameRngNavigation { get; set; }
    }
}
