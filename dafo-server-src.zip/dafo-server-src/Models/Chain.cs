﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Chain
    {
        public int Id { get; set; }
        public string Bname1 { get; set; }
        public string Bname2 { get; set; }
        public string Bname3 { get; set; }
    }
}
