﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class SubMax
    {
        public int Id { get; set; }
        public string Uname { get; set; }
        public string UnameMax { get; set; }

        public virtual Sigma UnameMaxNavigation { get; set; }
        public virtual Sigma UnameNavigation { get; set; }
    }
}
