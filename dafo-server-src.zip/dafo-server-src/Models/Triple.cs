﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Triple
    {
        public int Id { get; set; }
        public string Su { get; set; }
        public string Bp { get; set; }
        public string Ob { get; set; }
    }
}
