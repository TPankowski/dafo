﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class TreeViewTabOnto
    {
        public int Id { get; set; }
        public int? Tvid { get; set; }
        public int? Level { get; set; }
        public string Parent { get; set; }
        public int? Position { get; set; }
        public string Name { get; set; }
        public string Checked { get; set; }
        public string FuncType { get; set; }

        public virtual TreeViewPath Tv { get; set; }
    }
}
