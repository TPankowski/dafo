﻿using System;
using System.Collections.Generic;

namespace DafoApi.Models
{
    public partial class Spec1
    {
        public int Id { get; set; }
        public string Bname { get; set; }
        public string Const { get; set; }
        public string Uname { get; set; }

        public virtual Sigma BnameNavigation { get; set; }
        public virtual Sigma UnameNavigation { get; set; }
    }
}
