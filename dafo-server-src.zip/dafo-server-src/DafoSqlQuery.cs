﻿using DafoApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DafoApi
{
    class DafoSqlQuery
    {
        //---------------------------------------------------------------------------
        private String SqlExprEQAND(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            String sqlExp = "";
            if (expNode == null)
                return sqlExp;
            List<String> patterns = new List<String>();
            List<String> constants = new List<String>();
            char[] delimiter = new char[] { ',' };
            List<String> components = new List<String>();
            String expNodeName = expNode.Name;
            if (expNode.Name.Substring(0, 3) == "ALL" || expNode.Name.Substring(0, 3) == "ANY")
                expNodeName = expNode.Name.Substring(4, expNode.Name.Length - 4); // opuscic ALL 
            if (expNodeName.Contains("%") && expNodeName.IndexOf("(") == 0) //sekwencja z wzorcami
            {
                components = expNodeName.Substring(1, expNodeName.Length - 2).Split(delimiter).ToList();
                foreach (String s in components)
                    if (s.IndexOf("'%") == 0)
                        patterns.Add(s);
                    else
                        constants.Add(s);
                if (patterns.Count > 0)
                {
                    for (int p = 0; p <= patterns.Count - 1; p++)
                    {
                        if (p == 0)
                            sqlExp = tabVarPar + "." + rngMapPar + " LIKE " + patterns[p];
                        else
                            sqlExp = sqlExp + "\n AND " + tabVarPar + "." + rngMapPar + " LIKE " + patterns[p];
                    }
                    sqlExp = "(" + sqlExp + ")";
                }
                if (constants.Count > 0)
                {
                    for (int c = 0; c <= constants.Count - 1; c++)
                        sqlExp = sqlExp + "\n AND " + tabVarPar + "." + rngMapPar + " = " + constants[c];
                }
            }
            else
            if (expNodeName.IndexOf("(") == 0) //sekwencja ALL
            {
                string consString = expNodeName.Substring(1, expNodeName.Length - 2);
                while (true)
                {
                    int endConst = consString.IndexOf("','");
                    if (endConst < 0)
                    {
                        constants.Add(consString);
                        break;
                    }
                    constants.Add(consString.Substring(0, endConst) + "'");
                    consString = consString.Substring(endConst + 2);
                }

                for (int c = 0; c <= constants.Count - 1; c++)
                {
                    if (c == 0)
                        sqlExp = tabVarPar + "." + rngMapPar + " = " + constants[c];
                    else
                        sqlExp = sqlExp + "\n AND " + tabVarPar + "." + rngMapPar + " = " + constants[c];
                }
            }
            else
            if (expNodeName.IndexOf("%") >= 0) //wzorzec
                sqlExp = tabVarPar + "." + rngMapPar + " LIKE '" + expNodeName + "'" + "\n";
            else
                sqlExp = tabVarPar + "." + rngMapPar + " = '" + expNodeName + "'" + "\n";
            return sqlExp;
        }

        //------------------------------------------------------------
        private String SqlExprEQOR(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            String sqlExp = "";
            if (expNode == null)
                return sqlExp;
            List<String> patterns = new List<String>();
            List<String> constants = new List<String>();
            char[] delimiter = new char[] { ',' };
            List<String> components = new List<String>();
            String expNodeName = expNode.Name;
            if (expNode.Name.Substring(0, 3) == "ALL" || expNode.Name.Substring(0, 3) == "ANY")
                expNodeName = expNode.Name.Substring(4, expNode.Name.Length - 4); // opuscic ALL 
            if (expNodeName.Contains("%") && expNodeName.IndexOf("(") == 0) //sekwencja z wzorcami
            {
                components = expNodeName.Substring(1, expNodeName.Length - 2).Split(delimiter).ToList();
                foreach (String s in components)
                    if (s.IndexOf("'%") == 0)
                        patterns.Add(s);
                    else
                        constants.Add(s);
                if (patterns.Count > 0)
                {
                    for (int p = 0; p <= patterns.Count - 1; p++)
                    {
                        if (p == 0)
                            sqlExp = tabVarPar + "." + rngMapPar + " LIKE " + patterns[p];
                        else
                            sqlExp = sqlExp + "\n OR " + tabVarPar + "." + rngMapPar + " LIKE " + patterns[p];
                    }
                    sqlExp = "(" + sqlExp + ")";
                }
                if (constants.Count > 0)
                {
                    for (int c = 0; c <= constants.Count - 1; c++)
                        sqlExp = sqlExp + "\n OR " + tabVarPar + "." + rngMapPar + " = " + constants[c];
                }
            }
            else
            if (expNodeName.IndexOf("(") == 0) //sekwencja ALL
            {
                string consString = expNodeName.Substring(1, expNodeName.Length - 2);
                while (true)
                {
                    int endConst = consString.IndexOf("','");
                    if (endConst < 0)
                    {
                        constants.Add(consString);
                        break;
                    }
                    constants.Add(consString.Substring(0, endConst) + "'");
                    consString = consString.Substring(endConst + 2);
                }

                for (int c = 0; c <= constants.Count - 1; c++)
                {
                    if (c == 0)
                        sqlExp = tabVarPar + "." + rngMapPar + " = " + constants[c];
                    else
                        sqlExp = sqlExp + "\n OR " + tabVarPar + "." + rngMapPar + " = " + constants[c];
                }
            }
            else
            if (expNodeName.IndexOf("%") >= 0) //wzorzec
                sqlExp = tabVarPar + "." + rngMapPar + " LIKE '" + expNodeName + "'" + "\n";
            else
                sqlExp = tabVarPar + "." + rngMapPar + " = '" + expNodeName + "'" + "\n";
            return sqlExp;
        }

        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        // ponizej do usuniecia ??

        //---------------------------------------------------------------------------
        public string UPtoSQL(DafoTypes.ExpNode node)
        {
            // OP - object property
            string sqlQ = "";
            string tabMap = "";
            //SetCountState(node);
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var S = (from t in ontoCtx.Sigma
                         where t.Name == node.Name && t.Type == "U"
                         select new { TabMap = t.TabMap }).FirstOrDefault();
                tabMap = S.TabMap;
            if (node.cyclState == 1) // koncowe wystapienie CYCLE
            {
                string alias1 = node.VarName;
                int i = node.cyclStack.IndexOf('_');
                string CYCLE_COL = node.cyclStack.Substring(i + 1);
                node.Flag = "SELECT DISTINCT " + alias1 + ".Id AS Id, " +
                        alias1 + ".Id AS " + CYCLE_COL +" FROM " + tabMap + " AS " + alias1;
                sqlQ = node.Flag;
            }
            else
            {
                sqlQ = "SELECT " + node.VarName + ".Id" + " AS Id FROM " + tabMap + " AS " + node.VarName;
            }
            return sqlQ;
        }
        public string EQtoSQL(DafoTypes.ExpNode node, string domMap, string rngMap, string tabMap)
        { // 15.08.2019
            string whereExp;
            DafoTypes.ExpNode childNode = node.ChildNode;
            string WHERE = " WHERE ";
            if (childNode.NodeType == "NOT")
            {
                childNode = childNode.ChildNode;
                WHERE = " WHERE NOT ";
            }
            if (childNode.Name.Length >= 3 && (childNode.Name.Substring(0, 3) == "ALL" || childNode.Name.Substring(0, 3) == "ANY"))
            {
                if (childNode.Name.Substring(0, 3) == "ALL") //(node.Flag == "AND") // 
                    whereExp = WHERE + "(" + SqlExprEQAND(childNode, tabMap, node.VarName, domMap, rngMap, node.VarName, node.VarName) + ")";
                else
                    whereExp = WHERE + "(" + SqlExprEQOR(childNode, tabMap, node.VarName, domMap, rngMap, node.VarName, node.VarName) + ")";
            }
            else
            {
                string expNodeName = childNode.Name;
                if (expNodeName.IndexOf("%") >= 0) //wzorzec
                    whereExp = WHERE + "(" + node.VarName + "." + rngMap + " LIKE '" + expNodeName + "' " + ")";
                else // stała
                    whereExp = WHERE + "(" + node.VarName + "." + rngMap + " = '" + expNodeName + "' " + ")";
            }
            return whereExp;
        }

        //---------------------------------------------------------------------------
        public void OPDPtoSQL(DafoTypes.ExpNode node) // string joinExp, DafoTypes.ExpNode nodeEQ, Boolean groupBy)
        {
            // OP - object property
            string whereExp = "";
            string tabMap = "", domMap = "", rngMap = "";
            DafoTypes.ExpNode childNode = node.ChildNode;
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var S = (from t in ontoCtx.Sigma
                         where t.Name == node.Name
                         select new { TabMap = t.TabMap, AttMap = t.AttMap, DomMap = t.DomMap, RngMap = t.RngMap }).FirstOrDefault();
                tabMap = S.TabMap;
                domMap = S.DomMap;
                rngMap = S.RngMap;
            ontoCtx.Dispose();
            if (tabMap == null)
            {
                tabMap = tabMap;
            }
            int inversion = 0;
            inversion = StateOfInversion(node);
            string alias1 = node.VarName;
            string alias2 = node.VarName1;
            if (inversion==1)
            {
                alias1 = node.VarName1;
                alias2 = node.VarName;
            }
            string col1 = domMap;
            string col2 = rngMap;
            if (inversion == 1)
            {
                col1 = rngMap;
                col2 = domMap;
            }
            if (node.joinState == 1)// z dzieckiem EQ
                whereExp = EQtoSQL(node,domMap,rngMap,tabMap);
            if (node.countState == 0 && node.cyclState == 0) // nie ma count
            {

                if (node.joinState == 0 || node.joinState == 1) // nie ma count
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id "
                        +" FROM " + tabMap + " AS " + alias1 + whereExp;
                }
                if (node.joinState == 3)// robic JOIN
                {
                        node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id " //+ ", "alias1 + "." + col2
                        + " FROM " + tabMap + " AS " + alias1
                        + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                }
            }
            else
            if (node.countState == 1) // pierwszy poziom COUNT, END i nad nim cos jest
            {
                int i = node.aggStack.IndexOf('_');
                string AGG_COL = node.aggStack.Substring(i + 1);
                node.countColumn = col2; // rngMap;
                if (node.joinState == 0 || node.joinState == 1) // nie ma count
                    node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " //+ alias1 + "." + col2 + ", " +
                        + alias1 + "." + node.countColumn + " AS " + AGG_COL +
                        " FROM " + tabMap + " AS " + alias1 + whereExp;
                if (node.joinState == 3)// robic JOIN
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " //+ alias1 + "." + col2 + ", " +
                        +alias1 + "." + node.countColumn + " AS " + AGG_COL +
                        " FROM " + tabMap + " AS " + alias1
                    + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                }
            }
            else
            if (node.cyclState == 1) // koncowe wystapienie CYCLE END
            {
                int i = node.cyclStack.IndexOf('_');
                string CYCLE_COL = node.cyclStack.Substring(i + 1);
                //node.countColumn = col2; // rngMap;
                if (node.joinState == 0 || node.joinState == 1) // nie ma join
                    node.Flag = "SELECT DISTINCT " +alias1 + "." + col1 + " AS Id, " //+ alias1 + "." + col2 + ", " +
                        +alias1 + ".Id AS " + CYCLE_COL +
                        " FROM " + tabMap + " AS " + alias1 + whereExp;
                if (node.joinState == 3)// robic JOIN
                {
                    node.Flag = node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, "// + alias1 + "." + col2 + ", " +
                        +alias1 + ".Id AS " + CYCLE_COL +
                        " FROM " + tabMap + " AS " + alias1 +
                        " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                }
            }
            else
            if (node.countState == 2) // pośredni poziom COUNT, IN
            {
                int i = node.aggStack.IndexOf('_');
                string AGG_COL = node.aggStack.Substring(i + 1);
                if (node.joinState == 3)// robic JOIN
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, "// + alias1 + "." + col2 + ", " +
                        +alias2 + "." + AGG_COL +
                        " FROM " + tabMap + " AS " + alias1
                    + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                }
            }
            else
            if (node.cyclState == 2) // pośredni poziom CYCLE, IN
            {
                int i = node.cyclStack.IndexOf('_');
                //jest
                /*
                SELECT DISTINCT x7.Id AS Id, x7.ConfId, x2.x_x4_cycle FROM Proceedings AS x7
                JOIN(SELECT DISTINCT x2.Id AS Id  FROM Conference AS x2 WHERE(x2.Year = '2016')
                JOIN*/
                //ma byc:
                /*
                SELECT DISTINCT x7.Id AS Id, x7.ConfId, x2.x_x4_cycle FROM 
                               (SELECT x7.Id AS Id, x7.ConfId FROM Proceedings AS x7 
                                   JOIN(SELECT DISTINCT x2.Id AS Id FROM Conference AS x2 WHERE (x2.Year = '2016' )
                                   )AS x2 ON x2.Id=x7.ConfId -- INTERSECT
                           ) AS x7
SELECT DISTINCT x7.Id AS Id, x7.ConfId, x2.x_x4_cycle FROM 
(SELECT DISTINCT x7.Id AS Id, x7.ConfId FROM Proceedings AS x7 
JOIN(SELECT DISTINCT x2.Id AS Id  FROM Conference AS x2 WHERE (x2.Year = '2016' )
)AS x2 ON x2.Id = x7.ConfId 
AS x7

                --parent
SELECT x3.Id, x3.x_x5_cycle FROM ( --ConfId
--
SELECT x5.Id,x5.x_x5_cycle FROM(
--left
SELECT DISTINCT x3.Id AS Id  FROM Conference AS x3 WHERE (x3.Year = '2016' )
) AS x4
--right
JOIN(
--right
SELECT DISTINCT x3.ConfId AS Id, x5.x_x5_cycle FROM PCMember AS x3 
JOIN(SELECT DISTINCT x5.Id AS Id, x5.Id AS x_x5_cycle FROM Person AS x5

)AS x5 ON x5.Id = x3.PersonId) AS x5 ON x5.Id=x4.Id
--
)AS x3

                
                 */
                string CYCLE_COL = node.cyclStack.Substring(i + 1);
                if (false) // (node.ChildNode != null && node.ChildNode.ChildNode !=null && node.ChildNode.ChildNode.NodeType == "AND")
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " + alias1 + "." + col2 + ", " +
                            alias2 + "." + CYCLE_COL + " FROM ("
                            + "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " + alias1 + "." + col2 +
                            " FROM " + tabMap + " AS " + alias1
                            + " \nJOIN(" + node.ChildNode.ChildNode.LeftNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2
                            + "\n)AS " + alias1
                            + " \nJOIN(" + node.ChildNode.ChildNode.RightNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                    //node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " + alias1 + "." + col2 + ", " +
                    //        alias2 + "." + CYCLE_COL + " FROM ("
                    //        + "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " + alias1 + "." + col2 +
                    //        " FROM " + tabMap + " AS " + alias1
                    //        + " \nJOIN(" + 
                    //        node.ChildNode.ChildNode.LeftNode.Flag + "\n)AS " + node.ChildNode.ChildNode.Trans_Alias2
                    //            + " \nJOIN(" + node.ChildNode.ChildNode.RightNode.Flag + "\n)AS " + node.ChildNode.ChildNode.RightNode.Trans_Alias2
                    //            + " ON " + node.ChildNode.ChildNode.RightNode.Trans_Alias2 + ".Id = " + alias1 + ".Id"
                    //        + ")AS "+alias2+ " ON " + alias2 + ".Id = " + alias1 + "." + col1;
                }
                else
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, " //+ alias1 + "." + col2 + ", " +
                            + alias2 + "." + CYCLE_COL +
                            " FROM " + tabMap + " AS " + alias1
                        + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                }
            } else
            if (node.countState == 3) // najwyzszy poziom START, ktory ma ponizsze jedynym
            {
                int i = node.aggStack.IndexOf('_');
                string AGG_COL = node.aggStack.Substring(i + 1);
                if (node.countColumn == node.Name) // uwzglednic inversion czyli col2 zamiast rngMap
                    node.countColumn = col2; // rngMap;
                if (node.joinState == 3)// robic JOIN
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + ".Id FROM(\n" +
                        "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, COUNT(DISTINCT " +
                        alias2 + "." + AGG_COL + ") AS " + AGG_COL +
                        " FROM " + tabMap + " AS " + alias1
                    + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2 +
                    "\nGROUP BY " + alias1 + "." + col1 + ") AS " + alias1 + " \nWHERE " + alias1 + "." + AGG_COL + " " + node.countComp + " " + node.countNumber;
                }
            } else
            if (node.cyclState == 3) // najwyzszy poziom CYCLE START, 
            {
                int i = node.cyclStack.IndexOf('_');
                string CYCLE_COL = node.cyclStack.Substring(i + 1);
                //if (node.countColumn == node.Name) // uwzglednic inversion czyli col2 zamiast rngMap
                //    node.countColumn = col2; // rngMap;
                if (node.Parent.NodeType== "UP" &&  node.Parent.Parent == null) //(node.joinState == 3)// robic JOIN
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + ".Id FROM(\n" +
                        "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id," + alias2 + "." + CYCLE_COL +//+ ", "+alias1 + "." + col2 
                        " FROM " + tabMap + " AS " + alias1
                    + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2
                    + "\n)AS " + alias1+ "\nWHERE " + alias1 + ".Id = " + alias1 + "." + CYCLE_COL;
                } else
                {
                    node.Flag =
                        "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id," + alias2 + "." + CYCLE_COL +//+ ", "+alias1 + "." + col2 
                        " FROM " + tabMap + " AS " + alias1
                    + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2;
                    //+ "\n)AS " + alias1 + "\nWHERE " + alias1 + ".Id = " + alias1 + "." + CYCLE_COL;
                }
            } else
            if (node.countState == 4) // ostatni poziom END COUNT, ktory jest takze START
            {
                int i = node.aggStack.IndexOf('_');
                string AGG_COL = node.aggStack.Substring(i + 1);
                if (node.countColumn == node.Name) // uwzglednic inversion czyli col2 zamiast rngMap
                    node.countColumn = col2; // rngMap;
                if (node.joinState == 0 || node.joinState == 1) // nie ma join
                    node.Flag = "SELECT DISTINCT " + alias1 + ".Id FROM(\n" +
                        "SELECT DISTINCT " + alias1 + "." + col1 + " AS Id, COUNT(DISTINCT " +
                        alias1 + "." + node.countColumn + ") AS " + AGG_COL +
                        " FROM " + tabMap + " AS " + alias1 + whereExp +
                        "\nGROUP BY " + alias1 + "." + col1 + ") AS " + alias1 + " \nWHERE " + alias1 + "." + AGG_COL + " " + node.countComp + " " + node.countNumber;
                if (node.joinState == 3)// robic JOIN
                {
                    node.Flag = "SELECT DISTINCT " + alias1 + ".Id FROM(" +
                        " \nSELECT DISTINCT " + alias1 + "." + col1 + " AS Id, COUNT(DISTINCT " +
                        alias1 + "." + col2 + ") AS " + AGG_COL +
                        " FROM " + tabMap + " AS " + alias1
                    + " \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + ".Id = " + alias1 + "." + col2 +
                    //+" \nJOIN(" + node.ChildNode.Flag + "\n)AS " + alias2 + " ON " + alias2 + "." + col2+" = " + alias1 + "." + col2 + // 31.08.2019
                    "\nGROUP BY " + alias1 + "." + col1 + ") AS " + alias1 + " \nWHERE " + alias1 + "." + AGG_COL + " " + node.countComp + " " + node.countNumber;
                }
            }
        }


        //------------------------------------------------------------------------
        public void SetCountState(DafoTypes.ExpNode node) //08.2019
        {
            DafoTypes.ExpNode parentNode = node.Parent;
            if (node.NodeType != "BP")
            {
                return;
            }
            if (node.aggStack == null)
            {
                node.countState = 0; // nie ma Count
                return;
            }
            if (node.aggStack.Substring(0, 3) == "end")
            {
                node.countState = 1; // pierwszy (najnizszy) poziom Count
                if (parentNode.Parent == null || parentNode.Parent.aggStack == null || "AND,OR".Contains(parentNode.NodeType))
                {
                    node.countState = 4; // najnizszy i najwyzszy poziom
                }
                return;
            }
            if (node.aggStack.Substring(0, 2) == "in")
            {
                node.countState = 2; // // posredni poziom Count
                return;
            }
            if (node.aggStack.Substring(0, 5) == "start")
            {
                node.countState = 3; // // najwyzszy poziom Count, ale pod nim sa inne
                return;
            }
        }

        public void SetCycleState(DafoTypes.ExpNode node) //01.09.2019
        {
            DafoTypes.ExpNode parentNode = node.Parent;
            if (node.NodeType != "BP")
            {
                //return;
            }
            if (node.cyclStack == null)
            {
                node.cyclState = 0; // nie ma Cycle
                return;
            }
            if (node.cyclStack.Substring(0, 3) == "end")
            {
                node.cyclState = 1; // drugie wystapienie  zmiennej
                return;
            }
            if (node.cyclStack.Substring(0, 2) == "in")
            {
                node.cyclState = 2; // // posredni poziom cyklu
                string[] cycleArr = node.cyclStack.Split('_');
                if (node.VarName==cycleArr[1] || node.VarName1 == cycleArr[1])
                {
                    node.cyclState = 3;
                }
                return;
            }
            if (node.cyclStack.Substring(0, 5) == "start")
            {
                node.cyclState = 3; // // pierwsze wystapienie  zmiennej
                return;
            }
        }
        public int StateOfInversion(DafoTypes.ExpNode node)
        {
            int inversion = 0;
            DafoTypes.ExpNode procNode = node.Parent;
            while (procNode.NodeType != "UP")
            {
                procNode = procNode.Parent;
            }
            if (node.VarName == procNode.VarName)
                inversion = 0; // nie ma inwersji
            else
                inversion = 1; // jest inwersja
            return inversion;
        }
        //---------------------------------=================================================
        public void BPtoSQL(DafoTypes.ExpNode node)
        {
            //SetCountState(node);
            if (node.ChildNode == null)
            {
                node.joinState = 0;// lisc
                OPDPtoSQL(node);
            }
            else
            if (node.ChildNode.NodeType == "EQ")
            {
                node.joinState = 1;// lisc z EQ
                OPDPtoSQL(node);//z EQ}
            }
            else
            if (node.ChildNode.NodeType == "UP" && node.ChildNode.ChildNode == null)
            {
                node.joinState = 0;// lisc
                OPDPtoSQL(node);
            }
            else
            {
                node.joinState = 3;// nie lisc
                OPDPtoSQL(node);//z EQ}
            }
        }

        public string AndBPToSQL(DafoTypes.ExpNode leftNode, DafoTypes.ExpNode rightNode)
        {
            string left = leftNode.Flag;
            string right = rightNode.Flag;
            string sql = "";
            if (leftNode.ChildNode != null && leftNode.ChildNode.NodeType == "EQ" && rightNode.ChildNode != null && rightNode.ChildNode.NodeType == "EQ")
            {
                if (left.Contains("&id&"))
                {// tylko dla nested answer
                    sql = left;
                }
                else
                if (right.Contains("&id&"))
                { // tylko dla nested answer
                    sql = right;
                }
                else
                {
                    int wherePos = right.IndexOf("WHERE");
                    sql = left + " AND " + right.Substring(wherePos + 6);
                }
                return sql;
            }
            string[] cycleTab = { "", "", "", "" };
            string cycleStr = "";
            if (leftNode.cyclStack != null)
            {
                cycleTab = leftNode.cyclStack.Split('_');
                cycleStr = ", "+leftNode.Trans_Alias2 + "." + cycleTab[1] + "_" + cycleTab[2] + "_" + cycleTab[3];
            }
            else
            {
                if (rightNode.cyclStack != null)
                {
                    cycleTab = rightNode.cyclStack.Split('_');
                    cycleStr = ", " + rightNode.Trans_Alias1 + "." + cycleTab[1] + "_" + cycleTab[2] + "_" + cycleTab[3];
                }
            }
            if (leftNode.ChildNode != null) 
            {
                string leftAlias2 = leftNode.Trans_Alias1 + "_L";
                left = "SELECT DISTINCT " + leftAlias2 + ".Id AS Id" + cycleStr + " FROM(" + left + ")AS " + leftAlias2;
                string rightAlias1 = rightNode.Trans_Alias1;
                if (rightAlias1 == null)
                {
                    if (rightNode.LeftNode != null)
                    {
                        rightAlias1 = rightNode.LeftNode.Trans_Alias1;
                    }
                    else
                    {
                        rightAlias1 = "x_R"; // rightNode.ChildNode.Trans_Alias1;
                    }
                }

                sql = left + "\n JOIN(" + right + "\n)AS " + rightAlias1 + " ON " 
                    + rightAlias1 + ".Id = " + leftAlias2 + ".Id";
            }
            if (cycleStr != "")
            {
                if (leftNode.Parent.NodeType == "AND" && leftNode.Parent.Parent.NodeType == "UP" && leftNode.Parent.Parent.Parent == null)
                {
                    sql = "SELECT DISTINCT x.Id FROM(\n " + sql
                        + "\n)AS x WHERE x.Id = x." + cycleTab[1] + "_" + cycleTab[2] + "_" + cycleTab[3];
                }
            }
            return sql;
        }

        public string AndUPToSQL(DafoTypes.ExpNode leftNode, DafoTypes.ExpNode rightNode)
        {
            string left = leftNode.Flag;
            string right = rightNode.Flag;
            string sql = "";
            string leftAlias2 = leftNode.Trans_Alias1 + "_L";
            if (leftNode.ChildNode != null)
            {
                left = "SELECT DISTINCT " + leftAlias2 + ".Id AS Id" + " FROM(" + left + ") AS " + leftAlias2;
                string rightAlias1 = rightNode.Trans_Alias1;
                if (rightAlias1 == null)
                {
                    rightAlias1 = "x_R";
                }
                sql = left + "\n JOIN(" + right + "\n)AS " + rightAlias1 + " ON "
                    + rightAlias1 + ".Id = " + leftAlias2 + ".Id";
            }
            return sql;
        }

        //-------------------------------------------------------------
        public void EvaluateTree(DafoTypes.ExpNode node)
        {//rekurencyjne wypisywanie
            //DafoTypes.ExpNode procNode, procNode1,childNode;
            //Boolean groupBy = false;
            if (node == null)
                return;
            //usuniecie bledow
            if (node.ChildNode != null && node.ChildNode.Parent == null)
                node.ChildNode.Parent = node;
            if (node.LeftNode != null && node.LeftNode.Parent == null)
                node.LeftNode.Parent = node;
            if (node.RightNode != null && node.RightNode.Parent == null)
                node.RightNode.Parent = node;
            if (node.NodeType == "NOT")
            {
                if (node.PropagationPath == "") // poraz pierwszy
                {
                    node.Flag = node.Name;
                    node.PropagationPath = "Z";
                    EvaluateTree(node.ChildNode);
                }
                else
                if (node.PropagationPath == "Z")
                {
                    DafoTree dt = new DafoTree();
                    SetCountState(node);
                    string sqlExpr = node.ChildNode.Flag;
                    string maxSuperType = "";
                    string colName = "Id";
                    if (node.ChildNode.NodeType == "UP")
                    {
                        //maxSuperType = MaxSuperType(node.ChildNode.Name);
                        maxSuperType = dt.maxClass(node.ChildNode.Name);
                    }
                    else
                    if (node.ChildNode.NodeType == "BP")
                    {
                        DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                        DafoTypes.ExpNode parnode = node.Parent;
                        while (parnode.NodeType != "UP")
                        {
                            parnode = parnode.Parent;
                        }
                        maxSuperType = dt.maxClass(parnode.Name);
                        var sigma = (from s in ontoCtx.Sigma
                                     where s.Name == node.ChildNode.Name
                                     select new { s.DomMap, s.RngMap, s.TabMap, s.FuncType }).FirstOrDefault();
                        if (sigma.FuncType == "DF" || sigma.FuncType == "OF")
                        {
                            colName = "Id"; // 2019.09.16 sigma.RngMap;
                        }
                        else if (sigma.FuncType == "DM" || sigma.FuncType == "OM")
                        {
                            colName = "Id";
                        }
                    }
                    string select = "SELECT DISTINCT x." + colName + " FROM " + maxSuperType + " AS x";
                    node.Flag = "("+select + " \nEXCEPT\n " + "(" + sqlExpr + "))";
                    if (node.Parent == null)
                        return;
                    else
                        EvaluateTree(node.Parent);
                }
            }
            if (node.NodeType == "AND" || node.NodeType == "OR")
            {
                if (node.PropagationPath == "") // poraz pierwszy
                {
                    node.Flag = node.Name;
                    node.PropagationPath = "L";
                    EvaluateTree(node.LeftNode);
                }
                if (node.PropagationPath =="L") // lewe poddrzewo zrobione
                {
                    node.Flag = node.Name;
                    node.PropagationPath = "R";
                    EvaluateTree(node.RightNode);
                }
                if (node.PropagationPath == "R") // obydwa poddrzewa zrobione
                {
                    SetCountState(node);
                    SetCycleState(node);
                    if (node.NodeType == "OR")
                        node.Flag = node.LeftNode.Flag + "\n UNION\n (" + node.RightNode.Flag + ")";
                    else // AND
                    {
                        if (node.LeftNode.VarName1 == null || node.LeftNode.VarName1 == "" || node.Parent == null)// gdy q1(x) and q2(x)
                        {
                            //node.Flag = node.LeftNode.Flag + "\n INTERSECT\n (" + node.RightNode.Flag + ")";
                            node.Flag = AndUPToSQL(node.LeftNode, node.RightNode);
                        } 
                        else
                        //if (node.LeftNode != null && node.LeftNode.ChildNode != null 
                        //    && (node.LeftNode.Name.Substring(0,4)!="_Id_" || node.LeftNode.ChildNode.Name.Substring(0, 1)!="@"))
                        //{
                        //    node.Flag = node.LeftNode.Flag + "\n INTERSECT\n (" + node.RightNode.Flag+")";
                        //}
                        {
                            node.Flag = AndBPToSQL(node.LeftNode, node.RightNode);
                        }
                        //else //23.08.2019 -- teraz JOIN - tylko dla potrzeb CYCLE - jest ID z @x i tylko maksymalne klasy!! BEZ INTERSECT!!
                        //{
                        //    int inversion = 0;
                        //    inversion = StateOfInversion(node.LeftNode);
                        //    string alias1Left = node.LeftNode.VarName;
                        //    string alias2Left = node.LeftNode.VarName1;
                        //    if (inversion == 1)
                        //    {
                        //        alias1Left = node.LeftNode.VarName1;
                        //        alias2Left = node.LeftNode.VarName;
                        //    }
                        //    inversion = 0;
                        //    inversion = StateOfInversion(node.RightNode);
                        //    string alias1Right = node.RightNode.VarName;
                        //    string alias2Right = node.RightNode.VarName1;
                        //    if (inversion == 1)
                        //    {
                        //        alias1Right = node.RightNode.VarName1;
                        //        alias2Right = node.RightNode.VarName;
                        //    }

                        //    node.Flag = "SELECT DISTINCT " + alias1Left + ".Id " + " FROM(" + node.LeftNode.Flag + ") AS " + alias1Left
                        //        + " \nJOIN (" + node.RightNode.Flag + ") AS " + alias2Right
                        //                  + " ON " + alias2Right + ".Id=" + alias1Right + ".Id ";
                        //    if (node.Parent.cyclStack != null && node.Parent.cyclEq != null)
                        //    {
                        //        string[] cycleArr = node.Parent.cyclStack.Split('_');
                        //        if (cycleArr[0] == node.Parent.VarName)
                        //        {
                        //            node.Flag += " AND " + alias1Right + ".Id = " + node.Parent.cyclStack;
                        //        }
                        //    }
                        //}
                    }
                    if (node.Parent == null)
                        return;
                    else
                        EvaluateTree(node.Parent);
                }
            }
            if (node.NodeType == "UP")
            {
                if (node.PropagationPath == "")//nie bylem
                {
                    node.PropagationPath = "Z"; //zaliczony
                    if (node.ChildNode == null) // koncowy
                    {
                        SetCountState(node);
                        SetCycleState(node);
                        node.Flag = UPtoSQL(node);// object property to SQLnode.Flag; wazne dla Cycle ???
                        if (node.Parent == null)
                            return;
                        else
                            EvaluateTree(node.Parent);
                    }
                    EvaluateTree(node.ChildNode);
                }
                else
                {
                    //SetCountState(node);
                    //SetCycleState(node); tylko przepisanie potomka (?)
                    node.Flag = node.ChildNode.Flag;
                    if (node.Parent == null)
                    {
                        return;
                    }
                    else
                    {
                        EvaluateTree(node.Parent);
                    }
                }
            }
            if (node.NodeType == "BP")
            {
                if (node.PropagationPath == "")//nie bylem
                {
                    node.Flag = node.Name;
                    node.PropagationPath = "Z"; //zaliczony
                    if (node.ChildNode == null)// koncowy
                    {
                        SetCountState(node);
                        SetCycleState(node);
                        BPtoSQL(node);
                        if (node.Parent == null)
                        {
                            return;
                        }
                        else
                        {
                            EvaluateTree(node.Parent);
                        }
                    }
                    else
                    if (node.ChildNode.NodeType == "EQ")
                    {
                        SetCountState(node);
                        SetCycleState(node);
                        BPtoSQL(node);
                        if (node.Parent == null)
                        {
                            return;
                        }
                        else
                        {
                            EvaluateTree(node.Parent);
                        }
                    }
                    else
                    {
                        EvaluateTree(node.ChildNode);
                    }
                
                }
                else // wracam i tworze SQL
                {
                    SetCountState(node);
                    SetCycleState(node);
                    BPtoSQL(node);
                    if (node.Parent == null)
                    {
                        return;
                    }
                    else
                    {
                        EvaluateTree(node.Parent);
                    }
                }
            }
            return;
        }

         public String SqlQuery(DafoTypes.ExpNode node)
        {
            //ToStack(node);
            EvaluateTree(node);
            string sqlQ = node.Flag;
            return sqlQ;
        }

        private string bpTgtAlias(DafoTypes.ExpNode node)
        {
            string nodeName = node.Name;
            string domVar = node.VarName;
            string domVar1 = node.VarName1;
            string tabMap = "", domMap = "", rngMap = "";
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var S = (from t in ontoCtx.Sigma
                         where t.Name == nodeName
                         select new { TabMap = t.TabMap, AttMap = t.AttMap, DomMap = t.DomMap, RngMap = t.RngMap }).FirstOrDefault();
                tabMap = S.TabMap;
                domMap = S.DomMap;
                rngMap = S.RngMap;
            string alias = domVar1 + "." + rngMap; // domVar + "_" + domVar1;
            return alias;
        }

        private String SqlExprUnion(String query)
        {
            string prefix = query.Substring(0, query.IndexOf("{"));
            string q = query.Substring(query.IndexOf("{"));
            string result = "";
            //identyfikacja zagniezdzonych  "{ subquery }"
            int pocz = 0, kon = 0;
            var cq = q.ToCharArray();
            var sub = q.ToCharArray();
            for (int k = 0; k < cq.Length; k++)
            {
                if (cq[k] == '{')
                {
                    pocz = k;
                    continue;
                }
                if (cq[k] == '}')
                {
                    kon = k;
                    string subquery = q.Substring(pocz + 1, kon - pocz - 1);
                    if (subquery.Trim().Length == 0)
                        break;
                    if (result == "")
                        result = prefix + subquery;
                    else
                        result += " UNION " + prefix + subquery;
                    q = q.Substring(0, pocz) + q.Substring(k + 1);
                    q = q.Replace("{}", "");
                    if (q.Length == 0)
                        break;
                    if (q.IndexOf("{") < 0)// jest to postfix, nie ma potrzeby UNION
                    {
                        result = result.Replace("UNION ", q + " UNION ") + " " + q;
                        break;
                    }
                    cq = q.ToCharArray();
                    k = 0;
                    continue;
                }
            }
            return result;
        }
        private String SqlExprRoot(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            string sqlExp = "", sqlExpLeft = "", sqlExpRight = "";
            if (expNode == null)
                return sqlExp;
            if (expNode.NodeType == "AND")
            {
                sqlExpLeft = SqlExprRoot(expNode.LeftNode, tabMapPar, domVarPar, domMapPar, "", domVarPar, "");
                sqlExpRight = SqlExprRoot(expNode.RightNode, tabMapPar, domVarPar, domMapPar, "", domVarPar, "");
                if (sqlExpLeft.Substring(1, 5) == "WHERE" && sqlExpRight.Substring(1, 4) == "JOIN")
                    sqlExp = sqlExpRight + sqlExpLeft.Replace("WHERE", "AND");
                else
                {
                    if (sqlExpLeft.Substring(1, 5) == "JOIN" && sqlExpRight.Substring(1, 5) == "WHERE")
                        sqlExp = sqlExpLeft + sqlExpRight.Replace("WHERE", "AND");
                    else
                        if (sqlExpLeft.Substring(1, 5) == "WHERE" && sqlExpRight.Substring(1, 5) == "WHERE")
                        sqlExp = sqlExpLeft.Replace("WHERE", "WHERE (") + ")" + sqlExpRight.Replace("WHERE", "AND (") + ")";
                    else
                        sqlExp += sqlExpLeft + sqlExpRight;
                }
                return sqlExp;
            }
            if (expNode.NodeType == "OR")
            {
                DafoTypes.ExpNode leftNode = expNode.LeftNode;
                DafoTypes.ExpNode rightNode = expNode.RightNode;
                sqlExpLeft = SqlExprRoot(expNode.LeftNode, tabMapPar, domVarPar, domMapPar, "", domVarPar, "");
                sqlExpRight = SqlExprRoot(expNode.RightNode, tabMapPar, domVarPar, domMapPar, "", domVarPar, "");
                sqlExp += "{" + sqlExpLeft + "}" + "{" + sqlExpRight + "}";
                return sqlExp;
            }
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                var prop = (from t in ontoCtx.Sigma
                            where t.Name == expNode.Name
                            select new { TabMap = t.TabMap, DomMap = t.DomMap, RngMap = t.RngMap, FuncType = t.FuncType }).FirstOrDefault();
                if (prop == null || prop.TabMap == null)
                {
                    return "";
                }
                if (prop.FuncType == "DF") // || expNode.Name == "affiliation")
                    sqlExp = " WHERE " + SqlExprAtt(expNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                else
                    sqlExp = SqlExprJoin(expNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                return sqlExp;
        }

        private String SqlExprAtt(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            string sqlExp = "";
            if (expNode == null)
                return sqlExp;
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                string nodeName = expNode.Name;
                string domVar = expNode.VarName;
                string rngVar = expNode.VarName1;

                var prop = (from t in ontoCtx.Sigma
                            where t.Name == expNode.Name
                            select new { TabMap = t.TabMap, DomMap = t.DomMap, RngMap = t.RngMap, FuncType = t.FuncType }).FirstOrDefault();
                DafoTypes.ExpNode child = expNode.ChildNode;
                if (child == null)
                {
                    return "1=1"; //TRUE
                }
                if (child.NodeType == "OR")
                    sqlExp = SqlExprOR(expNode.ChildNode, prop.TabMap, domVar, prop.DomMap, prop.RngMap, domVar, rngVar);
                else //EQ
                if (expNode.Flag == "AND")
                    sqlExp = SqlExprEQAND(expNode.ChildNode, prop.TabMap, domVar, prop.DomMap, prop.RngMap, domVar, rngVar);
                else
                    sqlExp = SqlExprEQ(expNode.ChildNode, prop.TabMap, domVar, prop.DomMap, prop.RngMap, domVar, rngVar);
                return sqlExp;
        }

        private String SqlExprEQ(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            String sqlExp = "";
            if (expNode == null)
                return sqlExp;
            String expNodeName = expNode.Name;
            if (expNode.Name.Substring(0, 3) == "ALL" || expNode.Name.Substring(0, 3) == "ANY")
                expNodeName = expNode.Name.Substring(4, expNode.Name.Length - 4); // opuscic ANY 
            if (expNodeName.Contains("%") && expNodeName.IndexOf("(") == 0) //sekwencja z wzorcami
            {
                List<String> patterns = new List<String>();
                List<String> constants = new List<String>();
                char[] delimiter = new char[] { ',' };
                List<String> components = new List<String>();
                components = expNodeName.Substring(1, expNodeName.Length - 2).Split(delimiter).ToList();
                foreach (String s in components)
                    if (s.IndexOf("'%") == 0)
                        patterns.Add(s);
                    else
                        constants.Add(s);
                if (patterns.Count > 0)
                {
                    for (int p = 0; p <= patterns.Count - 1; p++)
                    {
                        if (p == 0)
                            sqlExp = tabVarPar + "." + rngMapPar + " LIKE " + patterns[p];
                        else
                            sqlExp = sqlExp + " OR " + tabVarPar + "." + rngMapPar + " LIKE " + patterns[p];
                    }
                    sqlExp = "(" + sqlExp + ")";
                }
                if (constants.Count > 0)
                {
                    sqlExp = sqlExp + " OR " + tabVarPar + "." + rngMapPar + " IN (";
                    for (int c = 0; c <= constants.Count - 1; c++)
                    {
                        if (c == constants.Count - 1)
                            sqlExp = sqlExp + constants[c] + ")";
                        else
                            sqlExp = sqlExp + constants[c] + ",";
                    }
                }
            }
            else
            if (expNodeName.IndexOf("(") == 0) //sekwencja ANY
                sqlExp = tabVarPar + "." + rngMapPar + " IN " + expNodeName + "\n";
            else
            if (expNodeName.IndexOf("%") >= 0) //wzorzec
                sqlExp = tabVarPar + "." + rngMapPar + " LIKE '" + expNodeName + "'" + "\n";
            else
                sqlExp = tabVarPar + "." + rngMapPar + " = '" + expNodeName + "'" + "\n";
            return sqlExp;
        }
        private String SqlExprJoin(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            String sqlExp = "";
            if (expNode == null)
                return sqlExp;
            string nodeName = expNode.Name;
            string domVar = expNode.VarName;
            string rngVar = expNode.VarName1;
            string tabMap = "", domMap = "", rngMap = "", tabVar = "", FuncType = "";
            if (expNode.NodeType == "UP" || expNode.NodeType == "BP")
            {
                DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                    var S = (from t in ontoCtx.Sigma
                             where t.Name == nodeName
                             select new { TabMap = t.TabMap, DomMap = t.DomMap, RngMap = t.RngMap, FuncType = t.FuncType }).FirstOrDefault();
                    tabMap = S.TabMap;
                    domMap = S.DomMap;
                    rngMap = S.RngMap;
                    FuncType = S.FuncType;
            }
            if (expNode.NodeType == "UP")
            {
                if (tabMapPar != tabMap)
                {
                    if (domVarPar == domVar)
                        sqlExp += " JOIN " + tabMap + " as " + domVar + " ON " + tabVarPar + "." + domMapPar + " = " + domVar + "." + domMap + "\n";
                    if (rngVarPar == domVar)
                        sqlExp += " JOIN " + tabMap + " as " + domVar + " ON " + tabVarPar + "." + rngMapPar + " = " + domVar + "." + domMap + "\n";
                }
                sqlExp += SqlExprJoin(expNode.ChildNode, tabMap, domVar, domMap, "", domVar, "");
            }
            if (expNode.NodeType == "BP")
            {
                if (FuncType == "DF") // || expNode.Name=="affiliation") //tutaj przed || calosc ok, gdy (ACMAuthor,DEXAPaper) obydwie semantyki 
                    sqlExp = " AND " + SqlExprAtt(expNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                else
                {
                    tabVar = tabVarPar;
                    if (tabMapPar != tabMap)
                    {
                        if (domVarPar == domVar)
                        {
                            if (FuncType == "OF")
                                tabVar = rngVar;
                            else
                                tabVar = domVar + "_" + rngVar; ;
                            sqlExp += " JOIN " + tabMap + " as " + tabVar + " ON " + tabVarPar + "." + domMapPar + " = " + tabVar + "." + domMap + "\n";
                        }
                        if (domVarPar == rngVar)
                        {
                            if (FuncType == "OF")
                                tabVar = domVar;
                            else
                                tabVar = rngVar + "_" + domVar;
                            sqlExp += " JOIN " + tabMap + " as " + tabVar + " ON " + tabVarPar + "." + domMapPar + " = " + tabVar + "." + rngMap + "\n";
                        }
                    }
                    sqlExp += SqlExprJoin(expNode.ChildNode, tabMap, tabVar, domMap, rngMap, domVar, rngVar);
                }
            }
            if (expNode.NodeType == "AND")
            {
                string sqlExpLeft = "", sqlExpRight = "";
                sqlExpLeft = SqlExprJoin(expNode.LeftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                sqlExpRight = SqlExprJoin(expNode.RightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                // sprawdzanie czy JOIN Paper as x1 ON z sqlExpRight jest juz w sqlExpLeft
                // jesli tak, to zastepujemy go AND
                string dupJOIN = "";
                int pozON = sqlExpRight.IndexOf("ON");
                if (pozON > 0)
                {
                    dupJOIN = sqlExpRight.Substring(0, pozON + 2);
                    if (sqlExpLeft.Contains(dupJOIN))
                        sqlExpRight = sqlExpRight.Replace(dupJOIN, " AND ");
                }
                sqlExp += sqlExpLeft + sqlExpRight;
            }
            if (expNode.NodeType == "OR")
            {
                DafoTypes.ExpNode leftNode = expNode.LeftNode;
                DafoTypes.ExpNode rightNode = expNode.RightNode;
                if (leftNode.NodeType == "UP" && rightNode.NodeType == "UP")
                {
                    string sqlExpLeft = SqlExprJoin(expNode.LeftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                    string sqlExpRight = SqlExprJoin(expNode.RightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                    sqlExp += "{" + sqlExpLeft + "}" + "{" + sqlExpRight + "}";
                    return sqlExp;
                }
                if (leftNode.NodeType == "UP" && rightNode.NodeType == "OR")
                {
                    string sqlExpLeft = SqlExprJoin(expNode.LeftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                    string sqlExpRight = SqlExprJoin(expNode.RightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                    sqlExp += "{" + sqlExpLeft + "}" + "{" + sqlExpRight + "}";
                    return sqlExp;
                }
                if (leftNode.NodeType == "OR" && rightNode.NodeType == "UP")
                {
                    string sqlExpLeft = SqlExprJoin(expNode.LeftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                    string sqlExpRight = SqlExprJoin(expNode.RightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                    sqlExp += "{" + sqlExpLeft + "}" + "{" + sqlExpRight + "}";
                    return sqlExp;
                }
                else
                    sqlExp = " AND " + SqlExprOR(expNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
            }
            if (expNode.NodeType == "EQ")
            {
                sqlExp += " AND " + SqlExprEQ(expNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
            }
            return sqlExp;
        }

        private String SqlExprOR(DafoTypes.ExpNode expNode, String tabMapPar, String tabVarPar, String domMapPar, String rngMapPar, String domVarPar, String rngVarPar)
        {
            string sqlExp = "";
            string sqlExpLeft = "", sqlExpRight = "";
            DafoTypes.ExpNode leftNode = expNode.LeftNode;
            DafoTypes.ExpNode rightNode = expNode.RightNode;
            if (leftNode.NodeType == "EQ" && rightNode.NodeType == "EQ")
            {
                sqlExpLeft = SqlExprEQ(leftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                sqlExpRight = SqlExprEQ(rightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                sqlExp = "(" + sqlExpLeft + " OR " + sqlExpRight + ")";
            }
            if (leftNode.NodeType == "EQ" && rightNode.NodeType == "OR")
            {
                sqlExpLeft = SqlExprEQ(leftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                sqlExp = "(" + sqlExpLeft + " OR " + SqlExprOR(rightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar) + ")";
            }
            if (leftNode.NodeType == "OR" && rightNode.NodeType == "EQ")
            {
                sqlExpRight = SqlExprEQ(rightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                sqlExp = "(" + SqlExprOR(leftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar) + " OR " + sqlExpRight + ")";
            }
            if (leftNode.NodeType == "OR" && rightNode.NodeType == "OR")
            {
                sqlExpRight = SqlExprEQ(rightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar);
                sqlExp = "(" + SqlExprOR(leftNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar) + " OR " + SqlExprOR(rightNode, tabMapPar, tabVarPar, domMapPar, rngMapPar, domVarPar, rngVarPar) + ")";
            }
            return sqlExp;
        }

        public string MaxSuperType(string typeName)
        {
            string maxSuperClass;
            DAFO_ONTOContext ontoCtx = new DAFO_ONTOContext();
                maxSuperClass = (from u in ontoCtx.MvMaxSuperClasses
                                 where u.Uname == typeName
                                 select u.UnameMax).FirstOrDefault();
                return maxSuperClass;
        }
    }
}
