﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;
using System.ComponentModel;
using System.Drawing.Design;
using System.Reflection;

namespace DafoApi
{
    
    public class DafoTypes
    {
        public static Boolean isRewritten = false;
        public static string answerType = "";
        public static string token;
        public class ExpNode
        {
            public ExpNode() { }
            public ExpNode(string nodeType, ExpNode parent,
                string varName, int varIndex, string varName1, int varIndex1,
                string name, string path, ExpNode childNode, ExpNode leftNode, ExpNode rightNode)
            {
                this.NodeType = nodeType;
                this.Parent = parent;
                this.VarName = varName;
                this.ValIndex = varIndex;
                this.VarName1 = varName1;
                this.ValIndex1 = varIndex1;
                this.Name = name; //UP,BP,Const
                this.Path = path;
                this.ChildNode = childNode;
                this.LeftNode = leftNode;
                this.RightNode = rightNode;
                this.InversionOf = "";
                this.Flag = "";
                this.PropagationPath = "";
            }
            public string NodeType;
            public ExpNode Parent;
            public string VarName;
            public int ValIndex;
            public string VarName1;
            public int ValIndex1;
            public string Name;
            public string Path;
            public ExpNode ChildNode;
            public ExpNode LeftNode;
            public ExpNode RightNode;
            public string InversionOf;
            public string JSONParentId;
            public string JSONId;
            public string Flag;
            public string PropagationPath;
            //public int NodeId;
            public IntPtr NodeId;
            public IntPtr ParentId;
            //internal readonly string nodeType;
            public string nodeType;
            public string aggStack;
            public string cyclStack;
            public string cyclEq;
            public string countCond;
            public string countColumn;
            public string countComp;
            public string countNumber;
            public int joinState;
            public int countState;
            public int cyclState;
            public string Map_TabMap;
            public string Map_DomMap;
            public string Map_RngMap;
            public string Map_FuncType;
            public string Trans_Col1;
            public string Trans_Col2;
            public string Trans_Alias1;
            public string Trans_Alias2;
        }
        public class VarTab
        {
            public VarTab(string varName, String varVal)
            {
                this.VarName = varName;
                this.VarVal = varVal;
            }
            public String VarName;
            public String VarVal;
        }
    }
}
